import { NextResponse } from 'next/server';

// 1x1 transparent GIF so browsers requesting /favicon.ico never display the default Next.js "N" icon
const TRANSPARENT_1X1_GIF = Buffer.from(
  'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
  'base64'
);

export async function GET() {
  return new NextResponse(TRANSPARENT_1X1_GIF, {
    status: 200,
    headers: {
      'Content-Type': 'image/gif',
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  });
}
