import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

// In-memory cache of synthesized English MP3 audio buffers so repeated ball calls
// ("B, 1" through "O, 75") are served instantaneously with zero latency.
const memoryAudioCache = new Map<string, { base64: string; mimeType: string }>();

async function fetchCleanEnglishTtsMp3(text: string): Promise<Buffer | null> {
  const urls = [
    `https://translate.googleapis.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en-US&q=${encodeURIComponent(text)}`,
    `https://translate.googleapis.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q=${encodeURIComponent(text)}`,
    `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q=${encodeURIComponent(text)}`,
  ];

  for (const url of urls) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          Accept: 'audio/mpeg, audio/*;q=0.9, */*;q=0.8',
        },
      });

      if (response.ok) {
        const arrayBuf = await response.arrayBuffer();
        if (arrayBuf.byteLength > 256) {
          return Buffer.from(arrayBuf);
        }
      }
    } catch {
      // Try next mirror URL
    }
  }

  return null;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const rawText = (searchParams.get('text') || '').trim().slice(0, 220);

  if (!rawText) {
    return NextResponse.json({ error: 'Missing text parameter' }, { status: 400 });
  }

  const cacheKey = `en-clean:${rawText.toLowerCase()}`;
  const cached = memoryAudioCache.get(cacheKey);
  if (cached) {
    const buffer = Buffer.from(cached.base64, 'base64');
    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': cached.mimeType,
        'Cache-Control': 'public, max-age=86400, immutable',
      },
    });
  }

  const mp3Buffer = await fetchCleanEnglishTtsMp3(rawText);
  if (!mp3Buffer) {
    return NextResponse.json({ error: 'TTS stream unavailable' }, { status: 502 });
  }

  const base64 = mp3Buffer.toString('base64');
  memoryAudioCache.set(cacheKey, { base64, mimeType: 'audio/mpeg' });

  return new NextResponse( new Uint8Array(mp3Buffer), {
    status: 200,
    headers: {
      'Content-Type': 'audio/mpeg',
      'Cache-Control': 'public, max-age=86400, immutable',
    },
  });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => ({}))) as {
      text?: string;
    };
    const rawText = (body.text || '').trim().slice(0, 220);

    if (!rawText) {
      return NextResponse.json({ error: 'Missing text' }, { status: 400 });
    }

    const cacheKey = `en-clean:${rawText.toLowerCase()}`;
    const cached = memoryAudioCache.get(cacheKey);
    if (cached) {
      return NextResponse.json({
        base64: cached.base64,
        mimeType: cached.mimeType,
        cached: true,
      });
    }

    const mp3Buffer = await fetchCleanEnglishTtsMp3(rawText);
    if (!mp3Buffer) {
      return NextResponse.json({ error: 'TTS stream unavailable' }, { status: 502 });
    }

    const payload = {
      base64: mp3Buffer.toString('base64'),
      mimeType: 'audio/mpeg',
    };
    memoryAudioCache.set(cacheKey, payload);

    return NextResponse.json(payload);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'TTS error' },
      { status: 500 }
    );
  }
}
