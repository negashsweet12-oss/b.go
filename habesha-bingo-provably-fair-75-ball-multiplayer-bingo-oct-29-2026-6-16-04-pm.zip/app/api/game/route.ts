import { NextRequest, NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';
import { eq, desc, asc, inArray } from 'drizzle-orm';
import { db } from '@/src/db/index';
import { rooms, rounds, tickets, wallets, users } from '@/src/db/schema';
import { getOnlinePlayersCount } from '@/src/db/users';
import {
  authenticatePlayerRequest,
  checkRateLimit,
  recordAuditLog,
  getClientIp,
} from '@/src/lib/auth';
import {
  getPoolCard,
  validateClaim,
  verifyRound,
  calculateRoundPayouts,
  getPatternLabel,
  BingoPattern,
} from '@/src/lib/bingo-engine';
import {
  syncRoomState,
  buildClientRoomState,
  settleRoundWithWinners,
  reserveRoundCards,
  getRoundCardLocks,
  clearUserRoundReservations,
  getGameBettingSchedule,
} from '@/src/lib/game-coordinator';
import { executeLedgerTransfer } from '@/src/lib/ledger';

export async function GET(req: NextRequest) {
  const authResult = await authenticatePlayerRequest(req);
  if (!authResult.ok) return authResult.response;
  const user = authResult.user;

  const { searchParams } = new URL(req.url);
  const roomIdParam = searchParams.get('roomId');
  const viewParam = searchParams.get('view');

  try {
    // 1. History view: Strictly isolated Live Mode vs Practice Mode history, per-round Won (left) & Lost (right) amounts, Provably Fair hash/seed, date filtering & pagination
    if (viewParam === 'history') {
      const modeFilter = (searchParams.get('mode') || 'LIVE').toUpperCase() === 'PRACTICE' ? 'PRACTICE' : 'LIVE';
      const dateFromParam = searchParams.get('dateFrom');
      const dateToParam = searchParams.get('dateTo');
      const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10) || 1);
      const pageSize = Math.min(50, Math.max(5, parseInt(searchParams.get('pageSize') || '10', 10) || 10));

      const dateFromMs = dateFromParam ? new Date(`${dateFromParam}T00:00:00.000Z`).getTime() : null;
      const dateToMs = dateToParam ? new Date(`${dateToParam}T23:59:59.999Z`).getTime() : null;

      const allRooms = await db.select().from(rooms);
      const roomMap = new Map(allRooms.map((r) => [r.id, r]));

      const myTicketsRaw = await db
        .select()
        .from(tickets)
        .where(eq(tickets.userId, user.id))
        .orderBy(desc(tickets.id))
        .limit(150);

      const pastRoundsRaw = await db
        .select()
        .from(rounds)
        .where(inArray(rounds.status, ['SETTLED', 'CANCELLED']))
        .orderBy(desc(rounds.id))
        .limit(50);

      const combinedRoundIds = Array.from(
        new Set([...myTicketsRaw.map((t) => t.roundId), ...pastRoundsRaw.map((r) => r.id)])
      );

      const relatedRounds =
        combinedRoundIds.length > 0
          ? await db.select().from(rounds).where(inArray(rounds.id, combinedRoundIds))
          : [];
      const roundMap = new Map(relatedRounds.map((r) => [r.id, r]));

      const allRoundTickets =
        combinedRoundIds.length > 0
          ? await db.select().from(tickets).where(inArray(tickets.roundId, combinedRoundIds))
          : [];

      const ticketUserIds = Array.from(new Set(allRoundTickets.map((t) => t.userId)));
      const ticketUsers =
        ticketUserIds.length > 0
          ? await db
              .select({ id: users.id, displayUsername: users.displayUsername, username: users.username })
              .from(users)
              .where(inArray(users.id, ticketUserIds))
          : [];
      const userMap = new Map(
        ticketUsers.map((u) => [u.id, u.displayUsername || u.username])
      );

      const ticketsByRound = new Map<number, typeof allRoundTickets>();
      for (const tk of allRoundTickets) {
        const list = ticketsByRound.get(tk.roundId) || [];
        list.push(tk);
        ticketsByRound.set(tk.roundId, list);
      }

      const withinDateRange = (isoOrDate: Date | string | null | undefined): boolean => {
        if (!dateFromMs && !dateToMs) return true;
        const ts = isoOrDate ? new Date(isoOrDate).getTime() : Date.now();
        if (Number.isNaN(ts)) return true;
        if (dateFromMs && !Number.isNaN(dateFromMs) && ts < dateFromMs) return false;
        if (dateToMs && !Number.isNaN(dateToMs) && ts > dateToMs) return false;
        return true;
      };

      const allMyGamesFormatted = myTicketsRaw.map((t) => {
        const r = roundMap.get(t.roundId);
        const rm = roomMap.get(t.roomId);
        const isPractice = Boolean(rm?.isPractice);
        const rTickets = ticketsByRound.get(t.roundId) || [];
        const winningCards = rTickets
          .filter((rt) => rt.payoutMinor > 0 || rt.claimValid === true)
          .map((rt) => ({
            cardIndex: rt.cardIndex,
            username: userMap.get(rt.userId) || 'Player',
            payoutMinor: rt.payoutMinor,
          }));
        const losingCards = rTickets
          .filter((rt) => !(rt.payoutMinor > 0 || rt.claimValid === true))
          .map((rt) => ({
            cardIndex: rt.cardIndex,
            username: userMap.get(rt.userId) || 'Player',
            pricePaidMinor: rt.pricePaidMinor,
          }));
        const isWon = t.payoutMinor > 0 || t.claimValid === true;
        const roundStatus = r?.status || 'OPEN';
        const isLost = roundStatus === 'SETTLED' && !isWon;
        const isRevealed = roundStatus === 'SETTLED' || roundStatus === 'CANCELLED';

        return {
          ticketId: t.id,
          roundId: t.roundId,
          roomId: t.roomId,
          roomNameEn: rm?.nameEn || 'Bingo Room',
          roomNameAm: rm?.nameAm || 'የቢንጎ ክፍል',
          isPractice,
          modeTag: isPractice ? 'PRACTICE_DEMO' : 'REAL_LIVE',
          cardIndex: t.cardIndex,
          pricePaidMinor: t.pricePaidMinor,
          payoutMinor: t.payoutMinor,
          wonAmountMinor: isWon ? t.payoutMinor : 0,
          lostAmountMinor: isLost ? t.pricePaidMinor : 0,
          roundStatus,
          winningPattern: r?.winningPattern || rm?.pattern || 'ONE_LINE',
          drawnCount: r?.drawnCount || 0,
          serverSeedHash: r?.serverSeedHash || '',
          serverSeed: isRevealed ? r?.serverSeed || null : null,
          won: isWon,
          lost: isLost,
          winningCards,
          losingCards,
          settledAt: r?.settledAt ? r.settledAt.toISOString() : null,
          createdAt: t.createdAt.toISOString(),
        };
      });

      // Strictly isolate Live Mode vs Practice Mode tickets
      const liveGamesAll = allMyGamesFormatted.filter(
        (g) => !g.isPractice && withinDateRange(g.settledAt || g.createdAt)
      );
      const practiceGamesAll = allMyGamesFormatted.filter(
        (g) => g.isPractice && withinDateRange(g.settledAt || g.createdAt)
      );

      // Group player's tickets by round so each round clearly shows Won Amount (Left) and Lost Amount (Right) + Provably Fair Seed/Hash
      const buildPlayerRoundsSummary = (gamesList: typeof allMyGamesFormatted) => {
        const roundGroups = new Map<
          number,
          {
            roundId: number;
            roomId: number;
            roomNameEn: string;
            roomNameAm: string;
            isPractice: boolean;
            modeTag: string;
            roundStatus: string;
            winningPattern: string;
            drawnCount: number;
            ballsDrawnCount: number;
            serverSeedHash: string;
            serverSeed: string | null;
            wonAmountMinor: number;
            lostAmountMinor: number;
            totalStakedMinor: number;
            wonCards: Array<{ cardIndex: number; payoutMinor: number }>;
            lostCards: Array<{ cardIndex: number; pricePaidMinor: number }>;
            activeCards: Array<{ cardIndex: number; pricePaidMinor: number }>;
            winningCards: Array<{ cardIndex: number; username: string; payoutMinor: number }>;
            roundWinningCards: Array<{ cardIndex: number; username: string; payoutMinor: number }>;
            settledAt: string | null;
            createdAt: string;
            timestampUtc: string;
          }
        >();

        for (const g of gamesList) {
          const existing = roundGroups.get(g.roundId);
          if (!existing) {
            roundGroups.set(g.roundId, {
              roundId: g.roundId,
              roomId: g.roomId,
              roomNameEn: g.roomNameEn,
              roomNameAm: g.roomNameAm,
              isPractice: g.isPractice,
              modeTag: g.modeTag,
              roundStatus: g.roundStatus,
              winningPattern: g.winningPattern,
              drawnCount: g.drawnCount,
              ballsDrawnCount: g.drawnCount,
              serverSeedHash: g.serverSeedHash,
              serverSeed: g.serverSeed,
              wonAmountMinor: g.wonAmountMinor,
              lostAmountMinor: g.lostAmountMinor,
              totalStakedMinor: g.pricePaidMinor,
              wonCards: g.won ? [{ cardIndex: g.cardIndex, payoutMinor: g.payoutMinor }] : [],
              lostCards: g.lost ? [{ cardIndex: g.cardIndex, pricePaidMinor: g.pricePaidMinor }] : [],
              activeCards:
                !g.won && !g.lost
                  ? [{ cardIndex: g.cardIndex, pricePaidMinor: g.pricePaidMinor }]
                  : [],
              winningCards: g.winningCards,
              roundWinningCards: g.winningCards,
              settledAt: g.settledAt,
              createdAt: g.createdAt,
              timestampUtc: g.settledAt || g.createdAt,
            });
          } else {
            existing.wonAmountMinor += g.wonAmountMinor;
            existing.lostAmountMinor += g.lostAmountMinor;
            existing.totalStakedMinor += g.pricePaidMinor;
            if (g.won) {
              existing.wonCards.push({ cardIndex: g.cardIndex, payoutMinor: g.payoutMinor });
            } else if (g.lost) {
              existing.lostCards.push({
                cardIndex: g.cardIndex,
                pricePaidMinor: g.pricePaidMinor,
              });
            } else {
              existing.activeCards.push({
                cardIndex: g.cardIndex,
                pricePaidMinor: g.pricePaidMinor,
              });
            }
          }
        }
        return Array.from(roundGroups.values()).sort((a, b) => b.roundId - a.roundId);
      };

      const liveMyRoundsAll = buildPlayerRoundsSummary(liveGamesAll);
      const practiceMyRoundsAll = buildPlayerRoundsSummary(practiceGamesAll);

      const allPastRoundsFormatted = pastRoundsRaw.map((r) => {
        const rm = roomMap.get(r.roomId);
        const isPractice = Boolean(rm?.isPractice);
        const fullSeq: number[] = JSON.parse(r.drawSequenceJson || '[]');
        const rTickets = ticketsByRound.get(r.id) || [];
        const winningCards = rTickets
          .filter((rt) => rt.payoutMinor > 0 || rt.claimValid === true)
          .map((rt) => ({
            cardIndex: rt.cardIndex,
            username: userMap.get(rt.userId) || 'Player',
            payoutMinor: rt.payoutMinor,
            isMe: rt.userId === user.id,
          }));
        const losingCards = rTickets
          .filter((rt) => !(rt.payoutMinor > 0 || rt.claimValid === true))
          .map((rt) => ({
            cardIndex: rt.cardIndex,
            username: userMap.get(rt.userId) || 'Player',
            pricePaidMinor: rt.pricePaidMinor,
            isMe: rt.userId === user.id,
          }));
        return {
          roundId: r.id,
          roomId: r.roomId,
          roomNameEn: rm?.nameEn || 'Bingo Room',
          roomNameAm: rm?.nameAm || 'የቢንጎ ክፍል',
          isPractice,
          modeTag: isPractice ? 'PRACTICE_DEMO' : 'REAL_LIVE',
          status: r.status,
          startsAt: r.startsAt.toISOString(),
          settledAt: r.settledAt?.toISOString() || null,
          serverSeedHash: r.serverSeedHash,
          serverSeed: r.serverSeed, // Safe because SETTLED / CANCELLED
          drawnNumbers: fullSeq.slice(0, r.drawnCount),
          drawnCount: r.drawnCount,
          potMinor: r.potMinor,
          houseFeeMinor: r.houseFeeMinor,
          prizeMinor: r.prizeMinor,
          winningPattern: r.winningPattern,
          cancelReason: r.cancelReason,
          winningCards,
          losingCards,
        };
      });

      const livePastRounds = allPastRoundsFormatted.filter(
        (r) => !r.isPractice && withinDateRange(r.settledAt || r.startsAt)
      );
      const practicePastRounds = allPastRoundsFormatted.filter(
        (r) => r.isPractice && withinDateRange(r.settledAt || r.startsAt)
      );

      const selectedGamesAll = modeFilter === 'PRACTICE' ? practiceGamesAll : liveGamesAll;
      const selectedRoundsAll = modeFilter === 'PRACTICE' ? practiceMyRoundsAll : liveMyRoundsAll;
      const selectedPastRounds = modeFilter === 'PRACTICE' ? practicePastRounds : livePastRounds;

      const totalRoundsCount = selectedRoundsAll.length;
      const totalPages = Math.max(1, Math.ceil(totalRoundsCount / pageSize));
      const safePage = Math.min(page, totalPages);
      const paginatedMyRounds = selectedRoundsAll.slice(
        (safePage - 1) * pageSize,
        safePage * pageSize
      );

      const nowIso = new Date().toISOString();

      return NextResponse.json({
        serverTimeUtc: nowIso,
        asOfTimestamp: nowIso,
        mode: modeFilter,
        pagination: {
          page: safePage,
          pageSize,
          totalItems: totalRoundsCount,
          totalPages,
          hasPrevPage: safePage > 1,
          hasNextPage: safePage < totalPages,
        },
        liveSummary: {
          totalRounds: liveMyRoundsAll.length,
          totalTickets: liveGamesAll.length,
          wonTicketsCount: liveGamesAll.filter((g) => g.won).length,
          lostTicketsCount: liveGamesAll.filter((g) => g.lost).length,
          totalWonMinor: liveGamesAll.reduce((acc, g) => acc + g.wonAmountMinor, 0),
          totalLostMinor: liveGamesAll.reduce((acc, g) => acc + g.lostAmountMinor, 0),
        },
        practiceSummary: {
          totalRounds: practiceMyRoundsAll.length,
          totalTickets: practiceGamesAll.length,
          wonTicketsCount: practiceGamesAll.filter((g) => g.won).length,
          lostTicketsCount: practiceGamesAll.filter((g) => g.lost).length,
          totalWonMinor: practiceGamesAll.reduce((acc, g) => acc + g.wonAmountMinor, 0),
          totalLostMinor: practiceGamesAll.reduce((acc, g) => acc + g.lostAmountMinor, 0),
        },
        myRounds: paginatedMyRounds,
        myGames: selectedGamesAll.slice(0, 50),
        pastRounds: selectedPastRounds.slice(0, 25),
      });
    }

    const userWallets = await db.select().from(wallets).where(eq(wallets.userId, user.id));
    const currentWallet = userWallets[0]
      ? {
          balanceMinor: userWallets[0].balanceMinor,
          lockedMinor: userWallets[0].lockedMinor,
          playBalanceMinor: userWallets[0].playBalanceMinor,
        }
      : undefined;

    // 2. Single Room Live State (cardPool included on initial load; client passes includePool=0 once cached)
    if (roomIdParam) {
      const roomId = Number(roomIdParam);
      const state = await buildClientRoomState(roomId, user.id);
      const onlinePlayersCount = await getOnlinePlayersCount(1);
      const includePool = searchParams.get('includePool') !== '0';

      return NextResponse.json({
        ...state,
        onlinePlayersCount,
        wallet: currentWallet,
        ...(includePool
          ? {
              cardPool: Array.from({ length: 120 }, (_, idx) => ({
                cardIndex: idx + 1,
                grid: getPoolCard(idx + 1),
              })),
            }
          : {}),
      });
    }

    // 3. Lobby: All active rooms with live synchronized round summaries
    const activeRooms = await db
      .select()
      .from(rooms)
      .where(eq(rooms.isActive, true))
      .orderBy(asc(rooms.id));

    const lobbyRooms = [];
    for (const rm of activeRooms) {
      const synced = await syncRoomState(rm.id);
      const rd = synced.round;
      const tks = synced.tickets;
      const distinctPlayers = new Set(tks.map((t) => t.userId)).size;
      const math = calculateRoundPayouts({
        ticketCount: tks.length,
        ticketPriceMinor: rm.ticketPriceMinor,
        houseFeeBps: rm.houseFeeBps,
        winnerIds: [],
      });

      const minReq = Math.max(2, rm.minPlayers || 2);
      lobbyRooms.push({
        id: rm.id,
        slug: rm.slug,
        nameEn: rm.nameEn,
        nameAm: rm.nameAm,
        ticketPriceMinor: rm.ticketPriceMinor,
        pattern: rm.pattern,
        minPlayers: minReq,
        minCardsPerPlayer: rm.minCardsPerPlayer,
        maxCardsPerPlayer: rm.maxCardsPerPlayer,
        houseFeeBps: rm.houseFeeBps,
        drawIntervalSeconds: rm.drawIntervalSeconds,
        cadenceSeconds: rm.cadenceSeconds,
        isPractice: rm.isPractice,
        activeRound: rd
          ? {
              id: rd.id,
              status: rd.status,
              startsAt: rd.startsAt.toISOString(),
              winningPattern: rd.winningPattern || rm.pattern,
              serverSeedHash: rd.serverSeedHash,
              drawnCount: rd.drawnCount,
              playerCount: distinctPlayers,
              minRequiredPlayers: minReq,
              waitingForMinPlayers: rd.status === 'OPEN' && distinctPlayers < minReq,
              ticketCount: tks.length,
              potMinor: math.potMinor,
              houseFeeMinor: math.baseHouseFeeMinor,
              prizeMinor: math.netPrizeMinor,
              myTicketCount: tks.filter((t) => t.userId === user.id).length,
            }
          : null,
      });
    }

    const onlinePlayersCount = await getOnlinePlayersCount(1);
    const bettingSchedule = await getGameBettingSchedule();

    return NextResponse.json({
      serverTimeUtc: new Date().toISOString(),
      onlinePlayersCount,
      bettingSchedule,
      wallet: currentWallet,
      rooms: lobbyRooms,
    });
  } catch (error) {
    console.error('Error in GET /api/game:', error);
    return NextResponse.json({ error: 'Failed to load game state' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const action = body?.action;

  // Publicly accessible provably fair verifier action for logged-in players
  if (action === 'verify_round') {
    const authResult = await authenticatePlayerRequest(req);
    if (!authResult.ok) return authResult.response;

    const serverSeed = String(body?.serverSeed || '').trim();
    const publishedSeedHash = String(body?.publishedSeedHash || '').trim();
    const roundId = String(body?.roundId || '').trim();
    const claimedDraws = Array.isArray(body?.claimedDraws)
      ? body.claimedDraws.map((n: any) => Number(n)).filter((n: number) => Number.isInteger(n))
      : undefined;

    if (!serverSeed || !publishedSeedHash || !roundId) {
      return NextResponse.json({ error: 'serverSeed, publishedSeedHash, and roundId are required' }, { status: 400 });
    }

    const result = verifyRound({
      serverSeed,
      publishedSeedHash,
      roundId,
      claimedDraws,
    });
    return NextResponse.json(result);
  }

  // All wagering/game actions require an active, non-self-excluded player
  const authResult = await authenticatePlayerRequest(req, { checkSelfExclusion: true });
  if (!authResult.ok) return authResult.response;
  const user = authResult.user;

  // 0. REAL-TIME CARTELA SELECTION LOCKING (Locks selected cartela immediately for all other players)
  if (action === 'select_card') {
    const roomId = Number(body?.roomId);
    const cardIndices: number[] = Array.isArray(body?.cardIndices)
      ? Array.from(new Set<number>(body.cardIndices.map((n: any) => Number(n)))).filter(
          (n: number) => Number.isInteger(n) && n >= 1 && n <= 400
        )
      : [];

    if (!Number.isInteger(roomId)) {
      return NextResponse.json({ error: 'Invalid roomId' }, { status: 400 });
    }

    try {
      const synced = await syncRoomState(roomId);
      const { room, round, tickets: existingTickets } = synced;
      const bettingSchedule = synced.bettingSchedule || (await getGameBettingSchedule());

      if (room.isPractice && bettingSchedule.isPracticeModeOpen === false) {
        const reason =
          bettingSchedule.practiceOffReason ||
          'የመለማመጃ ጨዋታ ለጊዜው ተዘግቷል (Practice Mode is temporarily turned OFF)';
        const resume = bettingSchedule.practiceResumeTime
          ? ` — የሚከፈትበት ሰዓት / Resumes at: ${bettingSchedule.practiceResumeTime}`
          : '';
        return NextResponse.json(
          {
            error: `🔒 የመለማመጃ ጨዋታ ተዘግቷል: ${reason}${resume}`,
            code: 'PRACTICE_MODE_CLOSED',
            reason,
            resumeTime: bettingSchedule.practiceResumeTime || null,
          },
          { status: 403 }
        );
      }

      if (
        !room.isPractice &&
        (!bettingSchedule.isBettingOpen || bettingSchedule.isRealGameModeOpen === false)
      ) {
        const timeStr =
          bettingSchedule.realGameResumeTime ||
          (bettingSchedule.scheduledGameTime
            ? new Date(bettingSchedule.scheduledGameTime).toLocaleString('en-US', {
                dateStyle: 'medium',
                timeStyle: 'short',
              })
            : '');
        const customReason = bettingSchedule.realGameOffReason || '';
        return NextResponse.json(
          {
            error: customReason
              ? `🔒 የእውነተኛ ጨዋታ ተዘግቷል: ${customReason}${timeStr ? ` — የሚከፈትበት ሰዓት / Resumes at: ${timeStr}` : ''}`
              : timeStr
              ? `ውርርድ ለጊዜው ተዘግቷል። ቀጣዩ ጨዋታ በ ${timeStr} ይጀምራል። (Betting is currently closed. Next game starts at ${timeStr})`
              : 'ውርርድ ለጊዜው ተዘግቷል! (Betting is currently closed.)',
            code: 'BETTING_CLOSED',
            scheduledGameTime: bettingSchedule.scheduledGameTime,
            reason: customReason || null,
            resumeTime: timeStr || null,
          },
          { status: 403 }
        );
      }

      if (!round || round.status !== 'OPEN') {
        return NextResponse.json(
          {
            error: 'ጨዋታ ተጀምሯል፣ እባክዎ ቀጣዩን ዙር ይጠብቁ (Game in progress — please wait for the next round).',
            code: 'ROUND_LOCKED_SPECTATOR_ONLY',
          },
          { status: 409 }
        );
      }

      const myOwnedSet = new Set(
        existingTickets.filter((t) => t.userId === user.id).map((t) => t.cardIndex)
      );
      const otherPurchasedCardIndices = existingTickets
        .filter((t) => t.userId !== user.id)
        .map((t) => t.cardIndex);
      const filteredIndices = cardIndices.filter((idx) => !myOwnedSet.has(idx));
      const remainingAllowed = Math.max(0, Math.max(4, room.maxCardsPerPlayer || 10) - myOwnedSet.size);

      const lockRes = reserveRoundCards({
        roundId: round.id,
        userId: user.id,
        username: user.displayUsername,
        cardIndices: filteredIndices,
        maxCards: remainingAllowed,
        purchasedCardIndices: otherPurchasedCardIndices,
        roundStartsAtMs: round.startsAt.getTime(),
      });

      const updatedState = await buildClientRoomState(room.id, user.id, { preSynced: synced });
      if (!lockRes.ok) {
        return NextResponse.json(
          {
            error: lockRes.error,
            reservedIndices: lockRes.reservedIndices,
            state: updatedState,
          },
          { status: 409 }
        );
      }

      return NextResponse.json({
        ok: true,
        reservedIndices: lockRes.reservedIndices,
        state: updatedState,
      });
    } catch (error) {
      console.error('Error locking selected card:', error);
      return NextResponse.json({ error: 'Failed to lock selected card' }, { status: 500 });
    }
  }

  // 1. BUY TICKETS (Only while round is OPEN! Supports buying 1 or multiple cartelas at once or adding more cartelas)
  if (action === 'buy_tickets') {
    const rl = checkRateLimit(`buy_tickets:${user.id}`, 60, 30);
    if (!rl.allowed) {
      return NextResponse.json({ error: 'Rate limit exceeded for buying tickets. Slow down.' }, { status: 429 });
    }

    const roomId = Number(body?.roomId);
    const rawCardIndices: number[] = Array.isArray(body?.cardIndices)
      ? Array.from(new Set<number>(body.cardIndices.map((n: unknown) => Number(n)))).filter(
          (n: number) => Number.isInteger(n) && n >= 1 && n <= 400
        )
      : [];

    if (!Number.isInteger(roomId) || rawCardIndices.length === 0) {
      return NextResponse.json(
        { error: 'እባክዎ ቢያንስ አንድ ካርቴላ ይምረጡ። (Please select at least one card)' },
        { status: 400 }
      );
    }

    try {
      const synced = await syncRoomState(roomId);
      const { room, tickets: existingTickets } = synced;
      let round = synced.round;
      const bettingSchedule = synced.bettingSchedule || (await getGameBettingSchedule());

      if (room.isPractice && bettingSchedule.isPracticeModeOpen === false) {
        const reason =
          bettingSchedule.practiceOffReason ||
          'የመለማመጃ ጨዋታ ለጊዜው ተዘግቷል (Practice Mode is temporarily turned OFF)';
        const resume = bettingSchedule.practiceResumeTime
          ? ` — የሚከፈትበት ሰዓት / Resumes at: ${bettingSchedule.practiceResumeTime}`
          : '';
        return NextResponse.json(
          {
            error: `🔒 የመለማመጃ ጨዋታ ተዘግቷል: ${reason}${resume}`,
            code: 'PRACTICE_MODE_CLOSED',
            reason,
            resumeTime: bettingSchedule.practiceResumeTime || null,
          },
          { status: 403 }
        );
      }

      if (
        !room.isPractice &&
        (!bettingSchedule.isBettingOpen || bettingSchedule.isRealGameModeOpen === false)
      ) {
        const timeStr =
          bettingSchedule.realGameResumeTime ||
          (bettingSchedule.scheduledGameTime
            ? new Date(bettingSchedule.scheduledGameTime).toLocaleString('en-US', {
                dateStyle: 'medium',
                timeStyle: 'short',
              })
            : '');
        const customReason = bettingSchedule.realGameOffReason || '';
        return NextResponse.json(
          {
            error: customReason
              ? `🔒 የእውነተኛ ጨዋታ ተዘግቷል: ${customReason}${timeStr ? ` — የሚከፈትበት ሰዓት / Resumes at: ${timeStr}` : ''}`
              : timeStr
              ? `ውርርድ ለጊዜው ተዘግቷል። ቀጣዩ ጨዋታ በ ${timeStr} ይጀምራል። (Betting is currently closed. Next game starts at ${timeStr})`
              : 'ውርርድ ለጊዜው ተዘግቷል! እባክዎ አድሚኑ እስኪከፍት ይጠብቁ። (Betting is currently closed. Please wait for the betting window to open.)',
            code: 'BETTING_CLOSED',
            scheduledGameTime: bettingSchedule.scheduledGameTime,
            reason: customReason || null,
            resumeTime: timeStr || null,
          },
          { status: 403 }
        );
      }

      if (!round) {
        return NextResponse.json(
          { error: 'No open round available (Maintenance mode may be active).' },
          { status: 400 }
        );
      }

      // CRITICAL RULE (Requirement 6): Late joiners cannot buy tickets once a round has transitioned to DRAWING/LOCKED!
      if (round.status !== 'OPEN') {
        return NextResponse.json(
          {
            error: 'ጨዋታ ተጀምሯል፣ እባክዎ ቀጣዩን ዙር ይጠብቁ (Game has started — please wait for the next round).',
            code: 'ROUND_LOCKED_SPECTATOR_ONLY',
          },
          { status: 409 }
        );
      }

      // If countdown is within <4s of expiring while round is still OPEN and waiting for players, give 15s grace so purchase succeeds cleanly
      if (round.startsAt.getTime() - Date.now() < 4000) {
        const extendedStartsAt = new Date(Date.now() + 15000);
        const extRows = await db
          .update(rounds)
          .set({ startsAt: extendedStartsAt })
          .where(eq(rounds.id, round.id))
          .returning();
        if (extRows[0]) {
          round = extRows[0];
        }
      }

      const myExistingTickets = existingTickets.filter((t) => t.userId === user.id);
      const myOwnedSet = new Set(myExistingTickets.map((t) => t.cardIndex));
      // Filter out any card indices already owned by this player in this round
      const cardIndices = rawCardIndices.filter((idx) => !myOwnedSet.has(idx));

      // Idempotent handling: if all requested cards were already bought by this user (e.g. retry after network hiccup), return success!
      if (cardIndices.length === 0 && myExistingTickets.length > 0) {
        clearUserRoundReservations(round.id, user.id);
        const updatedState = await buildClientRoomState(room.id, user.id, {
          preSynced: { ...synced, round },
        });
        return NextResponse.json({
          ok: true,
          state: updatedState,
        });
      }

      if (cardIndices.length === 0) {
        return NextResponse.json(
          { error: 'እባክዎ ተጨማሪ አዲስ ካርቴላ ይምረጡ። (Please select at least one new cartela).' },
          { status: 400 }
        );
      }

      const maxAllowedCards = Math.max(4, room.maxCardsPerPlayer || 10);
      const totalPlayerCards = myExistingTickets.length + cardIndices.length;

      if (totalPlayerCards < room.minCardsPerPlayer) {
        return NextResponse.json(
          { error: `Minimum ${room.minCardsPerPlayer} card(s) required in this room.` },
          { status: 400 }
        );
      }
      if (totalPlayerCards > maxAllowedCards) {
        return NextResponse.json(
          {
            error: `በአንድ ዙር ከ ${maxAllowedCards} በላይ ካርቴላ መያዝ አይቻልም። (Maximum ${maxAllowedCards} cards allowed per player per round).`,
          },
          { status: 400 }
        );
      }

      const takenByOthersSet = new Set(
        existingTickets.filter((t) => t.userId !== user.id).map((t) => t.cardIndex)
      );
      const activeLocks = getRoundCardLocks(round.id);
      const lockedByOthersSet = new Set(
        activeLocks.filter((l) => l.userId !== user.id).map((l) => l.cardIndex)
      );

      for (const idx of cardIndices) {
        if (!Number.isInteger(idx) || idx < 1 || idx > 400) {
          return NextResponse.json({ error: `Invalid card number #${idx}` }, { status: 400 });
        }
        if (takenByOthersSet.has(idx) || lockedByOthersSet.has(idx)) {
          return NextResponse.json(
            {
              error: `ካርቴላ #${idx} በሌላ ተጫዋች ተይዟል! እባክዎ ሌላ ካርቴላ ይምረጡ። (Card #${idx} was taken by another player).`,
            },
            { status: 409 }
          );
        }
      }

      const totalCostMinor = cardIndices.length * room.ticketPriceMinor;

      // Deduct from Play-Money balance if Practice Room, otherwise Real-Money Wallet via Ledger!
      if (room.isPractice) {
        const userWallets = await db.select().from(wallets).where(eq(wallets.userId, user.id));
        const w = userWallets[0];
        if (!w || w.playBalanceMinor < totalCostMinor) {
          return NextResponse.json(
            {
              error:
                'የልምምድ ሂሳብዎ በቂ አይደለም። በቦርሳ (Wallet) ውስጥ "+1,000 Free Play Birr" የሚለውን ይጫኑ። (Insufficient Practice Play Balance).',
            },
            { status: 400 }
          );
        }
        await db
          .update(wallets)
          .set({
            playBalanceMinor: w.playBalanceMinor - totalCostMinor,
            updatedAt: new Date(),
          })
          .where(eq(wallets.id, w.id));
      } else {
        const purchaseBatchTs = Date.now();
        for (const idx of cardIndices) {
          await executeLedgerTransfer({
            userId: user.id,
            type: 'BUY_TICKET',
            amountMinor: room.ticketPriceMinor,
            idempotencyKey: `buy_round_${round.id}_user_${user.id}_card_${idx}_${purchaseBatchTs}`,
            referenceId: `round:${round.id}`,
            note: `Bought Card #${idx} in ${room.nameEn} (Round #${round.id})`,
          });
        }
      }

      // Insert tickets in a single batch with onConflictDoNothing for retry safety
      const insertBatchTs = Date.now();
      const ticketValues = cardIndices.map((idx) => ({
        roundId: round.id,
        roomId: room.id,
        userId: user.id,
        cardIndex: idx,
        cardGridJson: JSON.stringify(getPoolCard(idx)),
        pricePaidMinor: room.ticketPriceMinor,
        idempotencyKey: `ticket_round_${round.id}_card_${idx}_${insertBatchTs}`,
      }));

      await db.insert(tickets).values(ticketValues).onConflictDoNothing();

      // Clear temporary reservation lock since ticket is now permanently purchased
      clearUserRoundReservations(round.id, user.id);

      // Fetch updated tickets for accurate pot math
      const updatedRoundTickets = await db
        .select()
        .from(tickets)
        .where(eq(tickets.roundId, round.id))
        .orderBy(asc(tickets.id));

      const math = calculateRoundPayouts({
        ticketCount: updatedRoundTickets.length,
        ticketPriceMinor: room.ticketPriceMinor,
        houseFeeBps: room.houseFeeBps,
        winnerIds: [],
      });

      const updatedRoundRows = await db
        .update(rounds)
        .set({
          potMinor: math.potMinor,
          houseFeeMinor: math.baseHouseFeeMinor,
          prizeMinor: math.netPrizeMinor,
          winningPattern: room.pattern,
        })
        .where(eq(rounds.id, round.id))
        .returning();

      const finalRound = updatedRoundRows[0] || round;

      const updatedState = await buildClientRoomState(room.id, user.id, {
        preSynced: {
          ...synced,
          round: finalRound,
          tickets: updatedRoundTickets,
        },
      });
      return NextResponse.json({
        ok: true,
        state: updatedState,
      });
    } catch (error: any) {
      if (error?.message?.includes('INSUFFICIENT_FUNDS')) {
        return NextResponse.json(
          {
            error:
              'ቀሪ ሂሳብዎ በቂ አይደለም። እባክዎ መጀመሪያ በቦርሳ (Wallet) በኩል ገቢ ያድርጉ። (Insufficient wallet balance).',
          },
          { status: 400 }
        );
      }
      console.error('Error buying tickets:', error);
      return NextResponse.json(
        { error: error?.message || 'ካርቴላውን መግዛት አልተቻለም። እባክዎ እንደገና ይሞክሩ። (Failed to purchase tickets)' },
        { status: 500 }
      );
    }
  }

  // 1B. CHANGE / SWAP HELD CARTELA (Allowed ONLY while round.status === 'OPEN', before the game starts)
  if (action === 'change_ticket') {
    const roomId = Number(body?.roomId);
    const oldCardIndex = Number(body?.oldCardIndex);
    const newCardIndex = Number(body?.newCardIndex);

    if (
      !Number.isInteger(roomId) ||
      !Number.isInteger(oldCardIndex) ||
      !Number.isInteger(newCardIndex) ||
      newCardIndex < 1 ||
      newCardIndex > 400
    ) {
      return NextResponse.json(
        { error: 'እባክዎ የሚቀይሩትን ትክክለኛ የካርቴላ ቁጥር ይምረጡ። (Invalid card numbers for swap).' },
        { status: 400 }
      );
    }

    try {
      const synced = await syncRoomState(roomId);
      const { room, round, tickets: existingTickets } = synced;

      if (!round || round.status !== 'OPEN') {
        return NextResponse.json(
          {
            error: 'ጨዋታው ስለተጀመረ ካርቴላ መቀየር አይቻልም። (Game has already started — cartela cannot be changed).',
            code: 'ROUND_LOCKED',
          },
          { status: 409 }
        );
      }

      const myTicket = existingTickets.find(
        (t) => t.userId === user.id && t.cardIndex === oldCardIndex
      );
      if (!myTicket) {
        return NextResponse.json(
          { error: `ካርቴላ #${oldCardIndex} በእርስዎ ስም አልተገኘም። (Card #${oldCardIndex} not found in your held cards).` },
          { status: 404 }
        );
      }

      if (oldCardIndex === newCardIndex) {
        const updatedState = await buildClientRoomState(room.id, user.id, { preSynced: synced });
        return NextResponse.json({ ok: true, state: updatedState });
      }

      const takenByAnyone = existingTickets.some((t) => t.cardIndex === newCardIndex);
      const activeLocks = getRoundCardLocks(round.id);
      const lockedByOther = activeLocks.some(
        (l) => l.userId !== user.id && l.cardIndex === newCardIndex
      );

      if (takenByAnyone || lockedByOther) {
        return NextResponse.json(
          {
            error: `ካርቴላ #${newCardIndex} በሌላ ተጫዋች ተይዟል! እባክዎ ሌላ ካርቴላ ይምረጡ። (Card #${newCardIndex} is already taken).`,
          },
          { status: 409 }
        );
      }

      await db
        .update(tickets)
        .set({
          cardIndex: newCardIndex,
          cardGridJson: JSON.stringify(getPoolCard(newCardIndex)),
          idempotencyKey: `ticket_round_${round.id}_card_${newCardIndex}_${Date.now()}`,
        })
        .where(eq(tickets.id, myTicket.id));

      clearUserRoundReservations(round.id, user.id);

      const updatedRoundTickets = await db
        .select()
        .from(tickets)
        .where(eq(tickets.roundId, round.id))
        .orderBy(asc(tickets.id));

      const updatedState = await buildClientRoomState(room.id, user.id, {
        preSynced: {
          ...synced,
          round,
          tickets: updatedRoundTickets,
        },
      });

      return NextResponse.json({
        ok: true,
        oldCardIndex,
        newCardIndex,
        state: updatedState,
      });
    } catch (error: any) {
      console.error('Error changing ticket:', error);
      return NextResponse.json(
        { error: error?.message || 'ካርቴላውን መቀየር አልተቻለም። (Failed to change cartela).' },
        { status: 500 }
      );
    }
  }

  // 1C. CANCEL / RELEASE HELD CARTELA WITH REFUND (Allowed ONLY while round.status === 'OPEN', before the game starts)
  if (action === 'cancel_ticket') {
    const roomId = Number(body?.roomId);
    const cardIndex = Number(body?.cardIndex);

    if (!Number.isInteger(roomId) || !Number.isInteger(cardIndex)) {
      return NextResponse.json({ error: 'Invalid roomId or cardIndex' }, { status: 400 });
    }

    try {
      const synced = await syncRoomState(roomId);
      const { room, round, tickets: existingTickets } = synced;

      if (!round || round.status !== 'OPEN') {
        return NextResponse.json(
          {
            error: 'ጨዋታው ስለተጀመረ ካርቴላ መሰረዝ ወይም መቀየር አይቻልም። (Game has already started — cartela cannot be cancelled).',
            code: 'ROUND_LOCKED',
          },
          { status: 409 }
        );
      }

      const myTicket = existingTickets.find(
        (t) => t.userId === user.id && t.cardIndex === cardIndex
      );
      if (!myTicket) {
        return NextResponse.json(
          { error: `ካርቴላ #${cardIndex} አልተገኘም። (Card #${cardIndex} not found).` },
          { status: 404 }
        );
      }

      await db.delete(tickets).where(eq(tickets.id, myTicket.id));

      const refundAmount = myTicket.pricePaidMinor || room.ticketPriceMinor;
      if (refundAmount > 0) {
        if (room.isPractice) {
          const userWallets = await db.select().from(wallets).where(eq(wallets.userId, user.id));
          const w = userWallets[0];
          if (w) {
            await db
              .update(wallets)
              .set({
                playBalanceMinor: w.playBalanceMinor + refundAmount,
                updatedAt: new Date(),
              })
              .where(eq(wallets.id, w.id));
          }
        } else {
          await executeLedgerTransfer({
            userId: user.id,
            type: 'REFUND',
            amountMinor: refundAmount,
            idempotencyKey: `refund_cancel_ticket_${myTicket.id}_${Date.now()}`,
            referenceId: `round:${round.id}`,
            note: `Refund for released Card #${cardIndex} before start in ${room.nameEn} (Round #${round.id})`,
          });
        }
      }

      clearUserRoundReservations(round.id, user.id);

      const updatedRoundTickets = await db
        .select()
        .from(tickets)
        .where(eq(tickets.roundId, round.id))
        .orderBy(asc(tickets.id));

      const math = calculateRoundPayouts({
        ticketCount: updatedRoundTickets.length,
        ticketPriceMinor: room.ticketPriceMinor,
        houseFeeBps: room.houseFeeBps,
        winnerIds: [],
      });

      const updatedRoundRows = await db
        .update(rounds)
        .set({
          potMinor: math.potMinor,
          houseFeeMinor: math.baseHouseFeeMinor,
          prizeMinor: math.netPrizeMinor,
        })
        .where(eq(rounds.id, round.id))
        .returning();

      const finalRound = updatedRoundRows[0] || round;

      const updatedState = await buildClientRoomState(room.id, user.id, {
        preSynced: {
          ...synced,
          round: finalRound,
          tickets: updatedRoundTickets,
        },
      });

      return NextResponse.json({
        ok: true,
        cancelledCardIndex: cardIndex,
        state: updatedState,
      });
    } catch (error: any) {
      console.error('Error cancelling ticket:', error);
      return NextResponse.json(
        { error: error?.message || 'ካርቴላውን መሰረዝ አልተቻለም። (Failed to cancel cartela).' },
        { status: 500 }
      );
    }
  }

  // Requirement 2: Players CANNOT manually start the game or force next round; only the server countdown timer starts rounds automatically!
  if (action === 'begin_draw_now' || action === 'next_round') {
    return NextResponse.json(
      {
        error:
          'ማንኛውም ተጫዋች በራሱ ፈቃድ ጨዋታውን ማስጀመር አይችልም። የሰዓት ቆጣሪው ሲጠናቀቅ ሲስተሙ ራሱ በአውቶማቲክ ጨዋታውን ያስጀምራል።',
      },
      { status: 403 }
    );
  }

  // 3. CLAIM BINGO (Server validates card + called numbers + pattern; false claims rate-limited; ties split pot!)
  if (action === 'claim_bingo') {
    const rl = checkRateLimit(`claim_bingo:${user.id}`, 4, 10);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `False claim rate-limit active. Please wait ${rl.retryAfterSeconds}s.` },
        { status: 429 }
      );
    }

    const roomId = Number(body?.roomId);
    try {
      const synced = await syncRoomState(roomId);
      const { room, round, tickets: roundTickets, draws } = synced;

      if (!round || round.status !== 'DRAWING') {
        return NextResponse.json(
          { error: 'Round is not currently drawing balls.' },
          { status: 409 }
        );
      }

      const myTickets = roundTickets.filter((t) => t.userId === user.id);
      if (myTickets.length === 0) {
        return NextResponse.json(
          { error: 'Spectators cannot claim BINGO in a running round.' },
          { status: 403 }
        );
      }

      const calledNumbers = draws.map((d) => d.ballNumber);
      const pattern = (round.winningPattern || room.pattern) as BingoPattern;

      // Validate if ANY of the player's tickets has achieved the room's winning pattern
      const evaluations = myTickets.map((t) => ({
        ticket: t,
        res: validateClaim(JSON.parse(t.cardGridJson), calledNumbers, pattern),
      }));
      const myWinningTickets = evaluations.filter((e) => e.res.valid).map((e) => e.ticket);

      if (myWinningTickets.length === 0) {
        const bestCompleted = evaluations.reduce((max, e) => Math.max(max, e.res.completedLinesCount), 0);
        const reqLines = evaluations[0]?.res.requiredLinesCount || 1;
        const patAm = getPatternLabel(pattern, 'am');
        const patEn = getPatternLabel(pattern, 'en');

        await recordAuditLog({
          actorUserId: user.id,
          actorUsername: user.displayUsername,
          action: 'FALSE_BINGO_CLAIM_REJECTED',
          metadata: { roundId: round.id, roomId: room.id, drawnCount: calledNumbers.length, pattern, bestCompleted, reqLines },
          ipAddress: ip,
        });

        return NextResponse.json(
          {
            valid: false,
            error: `ገና ቢንጎ አልሞላም! የዚህ ዙር ህግ «${patAm}» (${patEn}) ነው። እስካሁን ${bestCompleted}/${reqLines} ዝግ ብቻ ተጠናቋል።`,
          },
          { status: 400 }
        );
      }

      // Check all tickets in the round at this exact ball count so simultaneous winners split the pot!
      const allWinningTicketIds = roundTickets
        .filter((t) => validateClaim(JSON.parse(t.cardGridJson), calledNumbers, pattern).valid)
        .map((t) => t.id);

      await settleRoundWithWinners(round, room, roundTickets, allWinningTicketIds);

      await recordAuditLog({
        actorUserId: user.id,
        actorUsername: user.displayUsername,
        action: 'BINGO_CLAIM_WON_AND_SETTLED',
        metadata: {
          roundId: round.id,
          roomId: room.id,
          winningTicketIds: allWinningTicketIds,
          ballsDrawn: calledNumbers.length,
        },
        ipAddress: ip,
      });

      const updatedState = await buildClientRoomState(room.id, user.id);
      return NextResponse.json({
        ok: true,
        valid: true,
        state: updatedState,
      });
    } catch (error) {
      console.error('Error processing BINGO claim:', error);
      return NextResponse.json({ error: 'Failed to process BINGO claim' }, { status: 500 });
    }
  }

  return NextResponse.json({ error: 'Unknown game action' }, { status: 400 });
}
