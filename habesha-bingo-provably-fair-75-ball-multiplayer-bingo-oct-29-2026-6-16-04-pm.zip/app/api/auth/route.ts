import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';
import { eq, desc, and, or, sql } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '@/src/db/index';
import { users, wallets, ledgerEntries, notifications, passwordResets } from '@/src/db/schema';
import {
  WELCOME_BONUS_MINOR,
  hashPassword,
  verifyPassword,
  invalidatePasswordVerificationCache,
  isAdult18Plus,
  signSessionToken,
  getOrCreateUser,
  ensureInitialDataSeeded,
  isUserSelfExcluded,
  getOnlinePlayersCount,
  invalidateOnlinePlayersCache,
} from '@/src/db/users';
import {
  PLAYER_COOKIE_NAME,
  authenticatePlayerRequest,
  checkRateLimit,
  getClientIp,
  recordAuditLog,
  verifyFirebaseIdTokenSafe,
} from '@/src/lib/auth';
import { sendTelegramWelcomeNotification } from '@/src/lib/telegram';
import { getGameBettingSchedule } from '@/src/lib/game-coordinator';

function extractPhoneSuffix9(input: string): string | null {
  const digits = input.replace(/[^0-9]/g, '');
  if (digits.length === 9 && /^[79]\d{8}$/.test(digits)) {
    return digits;
  }
  if (digits.length === 10 && /^0[79]\d{8}$/.test(digits)) {
    return digits.slice(1);
  }
  if (digits.length === 12 && /^251[79]\d{8}$/.test(digits)) {
    return digits.slice(3);
  }
  if (digits.length >= 9) {
    const tail9 = digits.slice(-9);
    if (/^[79]\d{8}$/.test(tail9)) {
      return tail9;
    }
  }
  return null;
}

const registerSchema = z.object({
  username: z
    .string()
    .trim()
    .min(3, 'እባክዎ ቢያንስ 3 ፊደላት ያለው ሙሉ ስም ወይም ኢሜይል ያስገቡ (Name or Email must be at least 3 characters)')
    .max(100, 'ስም ወይም ኢሜይል በጣም ረጅም ነው (Name or Email is too long)')
    .refine(
      (val) =>
        /^[\p{L}\p{M}\p{N}_.\-\s+@]+$/u.test(val) ||
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val),
      'እባክዎ ትክክለኛ ሙሉ ስም (ከአባት ስም ጋር) ወይም የ Google Email አድራሻ ያስገቡ (Enter a valid full name or Google Email address)'
    ),
  password: z
    .string()
    .min(4, 'የይለፍ ቃል ቢያንስ 4 ፊደላት ወይም ቁጥሮች መሆን አለበት (Password must be at least 4 characters)'),
  dob: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date of birth must be YYYY-MM-DD'),
  phone: z
    .string({ message: 'እባክዎ ስልክ ቁጥርዎን ያስገቡ (Phone number is mandatory)' })
    .trim()
    .min(9, 'እባክዎ ትክክለኛ ስልክ ቁጥር ያስገቡ (Please enter a valid phone number, e.g. 09... or +2519...)')
    .max(20, 'ስልክ ቁጥሩ በጣም ረጅም ነው (Phone number is too long)')
    .refine(
      (val) => {
        const cleaned = val.replace(/[\s\-\(\)]/g, '');
        return /^(\+?251|0)?[79]\d{8}$/.test(cleaned) || /^\+?[0-9]{9,15}$/.test(cleaned);
      },
      'እባክዎ ትክክለኛ ስልክ ቁጥር ያስገቡ (Please enter a valid phone number, e.g. 0911223344 or +251911223344)'
    ),
  termsAccepted: z.literal(true, {
    message: 'You must confirm you are 18+ and accept the Terms',
  }),
});

async function buildUserProfileResponse(user: typeof users.$inferSelect, sessionToken?: string) {
  if (
    user.pendingLimitMinor !== null &&
    user.pendingLimitEffectiveAt &&
    new Date() >= user.pendingLimitEffectiveAt
  ) {
    await db
      .update(users)
      .set({
        dailyDepositLimitMinor: user.pendingLimitMinor,
        pendingLimitMinor: null,
        pendingLimitEffectiveAt: null,
      })
      .where(eq(users.id, user.id));
    user.dailyDepositLimitMinor = user.pendingLimitMinor;
    user.pendingLimitMinor = null;
    user.pendingLimitEffectiveAt = null;
  }

  if (sessionToken) {
    invalidateOnlinePlayersCache();
    void sendTelegramWelcomeNotification({
      username: user.displayUsername,
      message: `ሰላም ${user.displayUsername}! እንኳን ወደ Winner Bingo በደህና መጣህ/ሽ!`,
    }).catch(() => {});
  }

  let [userWallets, userNotifications, exclusion, onlinePlayersCount, bettingSchedule] = await Promise.all([
    db.select().from(wallets).where(eq(wallets.userId, user.id)).limit(1),
    db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, user.id))
      .orderBy(desc(notifications.id))
      .limit(25),
    isUserSelfExcluded(user.id),
    getOnlinePlayersCount(1),
    getGameBettingSchedule(),
  ]);

  if (userWallets.length === 0 && user.role === 'player') {
    userWallets = await db
      .insert(wallets)
      .values({
        userId: user.id,
        balanceMinor: WELCOME_BONUS_MINOR,
        lockedMinor: 0,
        playBalanceMinor: 100000,
      })
      .onConflictDoNothing()
      .returning();
    if (userWallets.length > 0) {
      await db
        .insert(ledgerEntries)
        .values({
          userId: user.id,
          type: 'WELCOME_BONUS',
          amountMinor: WELCOME_BONUS_MINOR,
          lockedDeltaMinor: 0,
          balanceAfterMinor: WELCOME_BONUS_MINOR,
          lockedAfterMinor: 0,
          idempotencyKey: `welcome_bonus_${user.id}`,
          referenceId: `SIGNUP_BONUS_${user.id}`,
          note: 'አዲስ ደንበኛ የእንኳን ደህና መጡ 20.00 ብር ቦነስ (New Player 20.00 ETB Welcome Bonus)',
        })
        .onConflictDoNothing();
    } else {
      userWallets = await db.select().from(wallets).where(eq(wallets.userId, user.id)).limit(1);
    }
  }

  const wallet = userWallets[0] || {
    balanceMinor: WELCOME_BONUS_MINOR,
    lockedMinor: 0,
    playBalanceMinor: 100000,
  };

  return {
    ok: true,
    ...(sessionToken ? { sessionToken } : {}),
    serverTimeUtc: new Date().toISOString(),
    onlinePlayersCount,
    bettingSchedule,
    user: {
      id: user.id,
      uid: user.uid,
      username: user.displayUsername,
      email: user.email,
      phone: user.phone,
      dob: user.dob,
      status: user.status,
      dailyDepositLimitMinor: user.dailyDepositLimitMinor,
      pendingLimitMinor: user.pendingLimitMinor,
      pendingLimitEffectiveAt: user.pendingLimitEffectiveAt?.toISOString() || null,
      selfExcluded: exclusion.excluded,
      selfExclusionEndsAt: exclusion.endsAt?.toISOString() || null,
    },
    wallet: {
      balanceMinor: wallet.balanceMinor,
      lockedMinor: wallet.lockedMinor,
      playBalanceMinor: wallet.playBalanceMinor,
    },
    notifications: userNotifications,
  };
}

function setCrossContextSessionCookie(res: NextResponse, cookieName: string, token: string, maxAgeSeconds: number) {
  res.cookies.set(cookieName, token, {
    httpOnly: true,
    sameSite: 'none',
    secure: true,
    path: '/',
    maxAge: maxAgeSeconds,
  });
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  if (searchParams.get('publicStats') === '1') {
    await ensureInitialDataSeeded();
    const [onlinePlayersCount, bettingSchedule] = await Promise.all([
      getOnlinePlayersCount(0),
      getGameBettingSchedule(),
    ]);
    return NextResponse.json({
      ok: true,
      serverTimeUtc: new Date().toISOString(),
      onlinePlayersCount,
      bettingSchedule,
    });
  }

  const authResult = await authenticatePlayerRequest(req);
  if (!authResult.ok) {
    return authResult.response;
  }

  try {
    const payload = await buildUserProfileResponse(authResult.user);
    return NextResponse.json(payload);
  } catch (error) {
    console.error('Error fetching player profile:', error);
    return NextResponse.json({ error: 'Failed to load profile' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  await ensureInitialDataSeeded();
  const ip = getClientIp(req);

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON request body' }, { status: 400 });
  }

  const action = body?.action;

  // 1. REGISTER (Player only — accepts Full Name with spaces, Username, OR Google Email)
  if (action === 'register') {
    const rl = checkRateLimit(`register:${ip}`, 40, 60);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `Too many attempts. Please wait ${rl.retryAfterSeconds}s.` },
        { status: 429 }
      );
    }

    const parsed = registerSchema.safeParse(body);
    if (!parsed.success) {
      const firstIssue = parsed.error.issues[0]?.message || 'Invalid registration data';
      return NextResponse.json({ error: firstIssue }, { status: 400 });
    }

    const { username: rawInput, password, dob, phone } = parsed.data;
    const cleanedInput = rawInput.replace(/\s+/g, ' ').trim();

    if (!isAdult18Plus(dob)) {
      await recordAuditLog({
        actorUsername: cleanedInput,
        action: 'REGISTER_REJECTED_UNDER_18',
        reason: `DOB ${dob} is under 18`,
        ipAddress: ip,
      });
      return NextResponse.json(
        { error: '18+ Only: You must be at least 18 years old to register and play.' },
        { status: 403 }
      );
    }

    const isEmailInput = cleanedInput.includes('@');
    const normalizedEmail = isEmailInput ? cleanedInput.toLowerCase() : '';
    const baseUsername = isEmailInput
      ? cleanedInput
          .split('@')[0]
          .replace(/[^a-zA-Z0-9_]/g, '_')
          .replace(/_+/g, '_')
          .replace(/^_|_$/g, '')
          .slice(0, 18)
          .toLowerCase() || 'player'
      : cleanedInput.toLowerCase();
    const normalizedUsername = baseUsername.length >= 3 ? baseUsername : `plr_${baseUsername}`;
    const displayUsername = isEmailInput ? cleanedInput.split('@')[0] : cleanedInput;

    try {
      // If registering with a Google Email that already exists from an earlier Google login, update its password and sign in!
      if (isEmailInput) {
        const existingByEmail = await db
          .select()
          .from(users)
          .where(and(sql`LOWER(${users.email}) = ${normalizedEmail}`, eq(users.role, 'player')));
        if (existingByEmail.length > 0) {
          const existingPlayer = existingByEmail[0];
          const matchesExistingPassword = verifyPassword(password, existingPlayer.passwordHash);

          if (matchesExistingPassword) {
            const sessionId = crypto.randomBytes(16).toString('hex');
            const updatedRows = await db
              .update(users)
              .set({
                phone: phone?.trim() || existingPlayer.phone,
                failedLoginAttempts: 0,
                lockedUntil: null,
                activeSessionId: sessionId,
                lastIp: ip,
                lastActiveAt: new Date(),
              })
              .where(eq(users.id, existingPlayer.id))
              .returning();
            const activeUser = updatedRows[0] || existingPlayer;
            const token = signSessionToken({
              userId: activeUser.id,
              uid: activeUser.uid,
              username: activeUser.displayUsername,
              role: 'player',
              sessionVersion: activeUser.sessionVersion,
              sessionId,
            });
            const profileData = await buildUserProfileResponse(activeUser, token);
            const res = NextResponse.json(profileData);
            setCrossContextSessionCookie(res, PLAYER_COOKIE_NAME, token, 60 * 60 * 24 * 7);
            return res;
          }

          return NextResponse.json(
            {
              error:
                'ይህ የ Google (Gmail) አድራሻ ቀድሞ ተመዝግቧል። እባክዎ ትክክለኛውን የይለፍ ቃል (Password) አስገብተው ይግቡ። (This email is already registered. Please enter your correct password to sign in.)',
            },
            { status: 401 }
          );
        }
      }

      const finalUsername = normalizedUsername;
      const existing = await db
        .select()
        .from(users)
        .where(
          or(
            eq(users.username, finalUsername),
            sql`REGEXP_REPLACE(LOWER(TRIM(${users.displayUsername})), '\\s+', ' ', 'g') = ${finalUsername}`
          )
        );
      if (existing.length > 0) {
        // If the customer already registered this account and entered their correct password on the Register tab, log them in seamlessly!
        const matchedExistingPlayer = existing.find(
          (u) => u.role === 'player' && u.status !== 'BLOCKED' && verifyPassword(password, u.passwordHash)
        );
        if (matchedExistingPlayer) {
          const sessionId = crypto.randomBytes(16).toString('hex');
          const updatedRows = await db
            .update(users)
            .set({
              phone: phone?.trim() || matchedExistingPlayer.phone,
              failedLoginAttempts: 0,
              lockedUntil: null,
              activeSessionId: sessionId,
              lastIp: ip,
              lastActiveAt: new Date(),
            })
            .where(eq(users.id, matchedExistingPlayer.id))
            .returning();
          const activeUser = updatedRows[0] || matchedExistingPlayer;
          const token = signSessionToken({
            userId: activeUser.id,
            uid: activeUser.uid,
            username: activeUser.displayUsername,
            role: 'player',
            sessionVersion: activeUser.sessionVersion,
            sessionId,
          });
          const profileData = await buildUserProfileResponse(activeUser, token);
          const res = NextResponse.json(profileData);
          setCrossContextSessionCookie(res, PLAYER_COOKIE_NAME, token, 60 * 60 * 24 * 7);
          return res;
        }

        return NextResponse.json(
          {
            error:
              'ይህ ስም ቀድሞ ተመዝግቧል። የእርስዎ አካውንት ከሆነ ትክክለኛውን የይለፍ ቃል (Password) አስገብተው «ይግቡ (Sign In)» የሚለውን ይጫኑ፤ አዲስ አካውንት ለመክፈት ከፈለጉ የአያት ስም ወይም ቁጥር ይጨምሩበት።',
          },
          { status: 409 }
        );
      }

      const safeSlug =
        finalUsername
          .replace(/\s+/g, '_')
          .replace(/[^a-zA-Z0-9_]/g, '')
          .slice(0, 20) || 'player';
      const sessionId = crypto.randomBytes(16).toString('hex');
      const uid = `usr_${safeSlug}_${crypto.randomBytes(4).toString('hex')}`;

      const insertedUsers = await db
        .insert(users)
        .values({
          uid,
          email: isEmailInput ? normalizedEmail : `${safeSlug}_${crypto.randomBytes(2).toString('hex')}@player.habeshabingo.et`,
          username: finalUsername,
          displayUsername,
          passwordHash: hashPassword(password, true),
          phone: phone?.trim() || null,
          dob,
          role: 'player',
          status: 'ACTIVE',
          sessionVersion: 1,
          activeSessionId: sessionId,
          lastIp: ip,
          deviceFingerprint: body.deviceFingerprint ? String(body.deviceFingerprint).slice(0, 120) : null,
          termsAcceptedAt: new Date(),
          termsVersion: '1.0',
        })
        .returning();

      const newUser = insertedUsers[0];
      await db.insert(wallets).values({
        userId: newUser.id,
        balanceMinor: WELCOME_BONUS_MINOR,
        lockedMinor: 0,
        playBalanceMinor: 100000,
      });

      await db
        .insert(ledgerEntries)
        .values({
          userId: newUser.id,
          type: 'WELCOME_BONUS',
          amountMinor: WELCOME_BONUS_MINOR,
          lockedDeltaMinor: 0,
          balanceAfterMinor: WELCOME_BONUS_MINOR,
          lockedAfterMinor: 0,
          idempotencyKey: `welcome_bonus_${newUser.id}`,
          referenceId: `SIGNUP_BONUS_${newUser.id}`,
          note: 'አዲስ ደንበኛ የእንኳን ደህና መጡ 20.00 ብር ቦነስ (New Player 20.00 ETB Welcome Bonus)',
        })
        .onConflictDoNothing();

      await db.insert(notifications).values({
        userId: newUser.id,
        type: 'ACCOUNT_STATUS',
        titleEn: 'Welcome! 20.00 ETB Bonus Credited!',
        titleAm: 'እንኳን ደህና መጡ! 20.00 ብር ቦነስ ተሰጥቶዎታል!',
        bodyEn:
          'Your account is ready! We have credited a 20.00 ETB Welcome Bonus directly to your real-money wallet, plus 1,000.00 Play Birr in the Practice Lounge.',
        bodyAm:
          'አካውንትዎ ተከፍቷል! ለአዲስ ደንበኛ የሚሰጥ 20.00 ብር የእንኳን ደህና መጡ ቦነስ ወደ ዋናው ዋሌትዎ ገብቶልዎታል! እንዲሁም በልምምድ ክፍል 1,000.00 የልምምድ ብር ተሰጥቶዎታል።',
      });

      await recordAuditLog({
        actorUserId: newUser.id,
        actorUsername: newUser.displayUsername,
        action: 'PLAYER_REGISTERED',
        ipAddress: ip,
      });

      const token = signSessionToken({
        userId: newUser.id,
        uid: newUser.uid,
        username: newUser.displayUsername,
        role: 'player',
        sessionVersion: newUser.sessionVersion,
        sessionId,
      });

      const profileData = await buildUserProfileResponse(newUser, token);
      const res = NextResponse.json(profileData);
      setCrossContextSessionCookie(res, PLAYER_COOKIE_NAME, token, 60 * 60 * 24 * 7);
      return res;
    } catch (error) {
      console.error('Registration error:', error);
      return NextResponse.json({ error: 'Registration failed. Please try again.' }, { status: 500 });
    }
  }

  // 2. LOGIN (Supports Full Name with spaces, Username, Phone Number, OR Google Email + mandatory password)
  if (action === 'login') {
    const rawUsername = String(body?.username || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const underscoreVariant = rawUsername.replace(/\s+/g, '_');
    const spaceVariant = rawUsername.replace(/_+/g, ' ');
    const phoneSuffix9 = extractPhoneSuffix9(rawUsername);
    const rawPassword = String(body?.password || '').trim();

    const ipLimit = checkRateLimit(`login_ip:${ip}`, 60, 60);
    const userLimit = checkRateLimit(`login_user:${rawUsername}`, 25, 60);
    if (!ipLimit.allowed || !userLimit.allowed) {
      return NextResponse.json(
        {
          error:
            'በጣም ብዙ የመግባት ሙከራ ተደርጓል። እባክዎ ከ 1 ደቂቃ በኋላ እንደገና ይሞክሩ (Too many login attempts. Please wait a minute and try again).',
        },
        { status: 429 }
      );
    }

    if (!rawUsername || !rawPassword) {
      return NextResponse.json(
        { error: 'እባክዎ ስም/ስልክ ቁጥር እና የይለፍ ቃል (Password) ያስገቡ (Please enter username/phone and password)' },
        { status: 401 }
      );
    }

    try {
      const emailPrefix = rawUsername.includes('@') ? rawUsername.split('@')[0] : rawUsername;
      const matchConditions = [
        eq(users.username, rawUsername),
        eq(users.username, underscoreVariant),
        eq(users.username, spaceVariant),
        sql`LOWER(TRIM(${users.email})) = ${rawUsername}`,
        sql`REGEXP_REPLACE(LOWER(TRIM(${users.displayUsername})), '\\s+', ' ', 'g') = ${rawUsername}`,
        sql`REGEXP_REPLACE(LOWER(TRIM(${users.displayUsername})), '\\s+', ' ', 'g') = ${spaceVariant}`,
        sql`LOWER(TRIM(${users.displayUsername})) = ${emailPrefix}`,
      ];

      if (phoneSuffix9) {
        matchConditions.push(
          sql`RIGHT(REGEXP_REPLACE(COALESCE(${users.phone}, ''), '[^0-9]', '', 'g'), 9) = ${phoneSuffix9}`
        );
      }

      const candidates = await db
        .select()
        .from(users)
        .where(and(eq(users.role, 'player'), or(...matchConditions)))
        .limit(10);

      // Prefer a candidate whose password matches (handles cases where two players share a phone number or display name)
      let user =
        candidates.find((c) => verifyPassword(rawPassword, c.passwordHash)) || candidates[0];

      // If the user entered a Google Email (@gmail.com / @googlemail.com) that hasn't been registered yet,
      // automatically create/link their Google Email account with the password they entered!
      if (!user && rawUsername.includes('@') && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(rawUsername) && rawPassword.length >= 4) {
        const googleUid = `google_email_${crypto.createHash('sha256').update(rawUsername).digest('hex').slice(0, 20)}`;
        const createdUser = await getOrCreateUser(googleUid, rawUsername, emailPrefix, '1998-05-15');
        const updatedWithPwd = await db
          .update(users)
          .set({ passwordHash: hashPassword(rawPassword, true) })
          .where(eq(users.id, createdUser.id))
          .returning();
        user = updatedWithPwd[0] || createdUser;
      }

      if (!user || user.role !== 'player') {
        return NextResponse.json(
          {
            error:
              'አካውንቱ አልተገኘም ወይም የተሳሳተ መረጃ አስገብተዋል። አዲስ ከሆኑ «አካውንት ክፈት (Register)» የሚለውን ይጫኑ (Account not found or invalid credentials).',
          },
          { status: 401 }
        );
      }

      if (user.lockedUntil && user.lockedUntil > new Date()) {
        const minsLeft = Math.max(1, Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000));
        return NextResponse.json(
          {
            error: `በተደጋጋሚ የተሳሳተ የይለፍ ቃል ስለገባ አካውንትዎ ለ ${minsLeft} ደቂቃ ተቆልፏል። የይለፍ ቃል ከረሱ «የይለፍ ቃል ረሱ?» የሚለውን ይጫኑ (Account temporarily locked. Try again in ${minsLeft} min).`,
            code: 'ACCOUNT_LOCKED',
          },
          { status: 423 }
        );
      }

      const passwordValid = verifyPassword(rawPassword, user.passwordHash);

      if (!passwordValid) {
        const attempts = user.failedLoginAttempts + 1;
        const lockUntil = attempts >= 10 ? new Date(Date.now() + 5 * 60 * 1000) : null;
        await db
          .update(users)
          .set({
            failedLoginAttempts: attempts,
            lockedUntil: lockUntil,
          })
          .where(eq(users.id, user.id));

        void recordAuditLog({
          targetUserId: user.id,
          targetUsername: user.displayUsername,
          action: lockUntil ? 'PLAYER_ACCOUNT_LOCKED_BRUTE_FORCE' : 'PLAYER_LOGIN_FAILED',
          reason: `Failed attempt #${attempts}`,
          ipAddress: ip,
        }).catch(() => {});

        return NextResponse.json(
          {
            error:
              'የተሳሳተ የይለፍ ቃል (Incorrect Password)! እባክዎ የይለፍ ቃልዎን በትክክል ያስገቡ ወይም ከረሱት «የይለፍ ቃል ረሱ? (Forgot Password?)» የሚለውን ይጫኑ።',
          },
          { status: 401 }
        );
      }

      if (user.status === 'BLOCKED') {
        const reasonSuffix = user.blockedReason ? ` — ምክንያት (Reason): ${user.blockedReason}` : '';
        return NextResponse.json(
          {
            error: `Your account is blocked, contact support${reasonSuffix}`,
            blockedReason: user.blockedReason || 'Policy violation',
            code: 'ACCOUNT_BLOCKED',
          },
          { status: 403 }
        );
      }

      const sessionId = crypto.randomBytes(16).toString('hex');
      const nowDate = new Date();
      const activeUser: typeof users.$inferSelect = {
        ...user,
        failedLoginAttempts: 0,
        lockedUntil: null,
        activeSessionId: sessionId,
        lastIp: ip,
        deviceFingerprint: body.deviceFingerprint
          ? String(body.deviceFingerprint).slice(0, 120)
          : user.deviceFingerprint,
        lastActiveAt: nowDate,
      };

      const token = signSessionToken({
        userId: activeUser.id,
        uid: activeUser.uid,
        username: activeUser.displayUsername,
        role: 'player',
        sessionVersion: activeUser.sessionVersion,
        sessionId,
      });

      const [, profileData] = await Promise.all([
        db
          .update(users)
          .set({
            failedLoginAttempts: 0,
            lockedUntil: null,
            activeSessionId: sessionId,
            lastIp: ip,
            deviceFingerprint: activeUser.deviceFingerprint,
            lastActiveAt: nowDate,
          })
          .where(eq(users.id, user.id)),
        buildUserProfileResponse(activeUser, token),
      ]);

      const res = NextResponse.json(profileData);
      setCrossContextSessionCookie(res, PLAYER_COOKIE_NAME, token, 60 * 60 * 24 * 7);
      return res;
    } catch (error) {
      console.error('Login error:', error);
      return NextResponse.json({ error: 'Login failed. Please try again.' }, { status: 500 });
    }
  }

  // 3. DIRECT GOOGLE EMAIL + MANDATORY PASSWORD LOGIN
  if (action === 'firebase_login' || action === 'google_email_login') {
    const rawEmail = String(body?.email || '').trim().toLowerCase();
    const rawPassword = String(body?.password || '').trim();
    const rawDisplayName = body?.displayName ? String(body.displayName).trim() : undefined;
    const rawDob = String(body?.dob || '1998-05-15');
    const dob = isAdult18Plus(rawDob) ? rawDob : '1998-05-15';

    try {
      if (!rawEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(rawEmail)) {
        return NextResponse.json(
          { error: 'እባክዎ ትክክለኛ የ Google Email አድራሻ ያስገቡ (Please enter a valid Google Email address).' },
          { status: 400 }
        );
      }

      // Strictly require password for every Google Email login
      if (!rawPassword || rawPassword.length < 4) {
        return NextResponse.json(
          {
            error:
              'እባክዎ የመግቢያ የይለፍ ቃልዎን (Password — ቢያንስ 4 ፊደላት/ቁጥሮች) ያስገቡ (Password is mandatory to sign in).',
          },
          { status: 400 }
        );
      }

      const resolvedUid = `google_email_${crypto.createHash('sha256').update(rawEmail).digest('hex').slice(0, 20)}`;
      const resolvedEmail = rawEmail;
      const resolvedName = rawDisplayName;

      const user = await getOrCreateUser(resolvedUid, resolvedEmail, resolvedName, dob);

      if (user.lockedUntil && user.lockedUntil > new Date()) {
        const minsLeft = Math.max(1, Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000));
        return NextResponse.json(
          {
            error: `በተደጋጋሚ የተሳሳተ የይለፍ ቃል ስለገባ አካውንትዎ ለ ${minsLeft} ደቂቃ ተቆልፏል። (Account temporarily locked. Try again in ${minsLeft} min).`,
            code: 'ACCOUNT_LOCKED',
          },
          { status: 423 }
        );
      }

      // Strictly verify the user's password (or set it if brand-new Google account)
      const hasUserSetPassword =
        user.passwordHash.startsWith('scrypt_set$') || user.uid.startsWith('usr_');

      if (hasUserSetPassword) {
        const isPwdValid = verifyPassword(rawPassword, user.passwordHash);
        if (!isPwdValid) {
          const attempts = user.failedLoginAttempts + 1;
          const lockUntil = attempts >= 10 ? new Date(Date.now() + 5 * 60 * 1000) : null;
          await db
            .update(users)
            .set({
              failedLoginAttempts: attempts,
              lockedUntil: lockUntil,
            })
            .where(eq(users.id, user.id));

          return NextResponse.json(
            {
              error:
                'የተሳሳተ የይለፍ ቃል (Incorrect Password)! እባክዎ የዚህን አካውንት ትክክለኛ የይለፍ ቃል ያስገቡ።',
            },
            { status: 401 }
          );
        }
      } else {
        // First time setting a password for this Google account — bind it permanently!
        invalidatePasswordVerificationCache(user.passwordHash);
        const newHash = hashPassword(rawPassword, true);
        await db
          .update(users)
          .set({ passwordHash: newHash })
          .where(eq(users.id, user.id));
        user.passwordHash = newHash;
      }

      if (user.status === 'BLOCKED') {
        const reasonSuffix = user.blockedReason ? ` — ምክንያት (Reason): ${user.blockedReason}` : '';
        return NextResponse.json(
          {
            error: `Your account is blocked, contact support${reasonSuffix}`,
            blockedReason: user.blockedReason || 'Policy violation',
            code: 'ACCOUNT_BLOCKED',
          },
          { status: 403 }
        );
      }

      const sessionId = crypto.randomBytes(16).toString('hex');
      const updatedRows = await db
        .update(users)
        .set({
          failedLoginAttempts: 0,
          lockedUntil: null,
          activeSessionId: sessionId,
          lastIp: ip,
          lastActiveAt: new Date(),
        })
        .where(eq(users.id, user.id))
        .returning();

      const activeUser = updatedRows[0] || user;

      // Ensure welcome notification exists if brand-new user
      const existingNotifs = await db
        .select()
        .from(notifications)
        .where(eq(notifications.userId, activeUser.id))
        .limit(1);
      if (existingNotifs.length === 0) {
        await db.insert(notifications).values({
          userId: activeUser.id,
          type: 'ACCOUNT_STATUS',
          titleEn: 'Welcome! 20.00 ETB Bonus Credited!',
          titleAm: 'እንኳን ደህና መጡ! 20.00 ብር ቦነስ ተሰጥቶዎታል!',
          bodyEn:
            'Signed in with Google! A 20.00 ETB Welcome Bonus has been credited to your real-money wallet, plus 1,000.00 Play Birr in the Practice Lounge.',
          bodyAm:
            'በ Google አካውንትዎ በተሳካ ሁኔታ ገብተዋል! ለአዲስ ደንበኛ የሚሰጥ 20.00 ብር የእንኳን ደህና መጡ ቦነስ ወደ ዋናው ዋሌትዎ ገብቶልዎታል!',
        });
      }

      await recordAuditLog({
        actorUserId: activeUser.id,
        actorUsername: activeUser.displayUsername,
        action: 'PLAYER_GOOGLE_LOGIN_SUCCESS',
        ipAddress: ip,
      });

      const token = signSessionToken({
        userId: activeUser.id,
        uid: activeUser.uid,
        username: activeUser.displayUsername,
        role: 'player',
        sessionVersion: activeUser.sessionVersion,
        sessionId,
      });

      const profileData = await buildUserProfileResponse(activeUser, token);
      const res = NextResponse.json(profileData);
      setCrossContextSessionCookie(res, PLAYER_COOKIE_NAME, token, 60 * 60 * 24 * 7);
      return res;
    } catch (error) {
      console.error('Firebase login verification error:', error);
      return NextResponse.json({ error: 'Google Sign-In verification failed. Please try again.' }, { status: 401 });
    }
  }

  // 4. LOGOUT (Current device — strictly revokes active session so re-entry requires password)
  if (action === 'logout' || action === 'logout_all') {
    const authResult = await authenticatePlayerRequest(req);
    if (authResult.ok) {
      await db
        .update(users)
        .set({
          sessionVersion: authResult.user.sessionVersion + 1,
          activeSessionId: null,
          lastActiveAt: new Date(0),
        })
        .where(eq(users.id, authResult.user.id));
    }
    invalidateOnlinePlayersCache();
    const res = NextResponse.json({ ok: true });
    res.cookies.delete(PLAYER_COOKIE_NAME);
    return res;
  }

  // 6. CHANGE PASSWORD (Requires current password)
  if (action === 'change_password') {
    const authResult = await authenticatePlayerRequest(req);
    if (!authResult.ok) return authResult.response;

    const currentPassword = String(body?.currentPassword || '');
    const newPassword = String(body?.newPassword || '');
    if (newPassword.length < 4) {
      return NextResponse.json(
        { error: 'አዲሱ የይለፍ ቃል ቢያንስ 4 ፊደላት/ቁጥሮች መሆን አለበት (New password must be at least 4 characters)' },
        { status: 400 }
      );
    }

    if (!verifyPassword(currentPassword, authResult.user.passwordHash)) {
      return NextResponse.json({ error: 'Current password is incorrect' }, { status: 400 });
    }

    const oldPasswordHash = authResult.user.passwordHash;
    const newPasswordHash = hashPassword(newPassword, true);
    const newSessionVersion = authResult.user.sessionVersion + 1;
    const newSessionId = crypto.randomBytes(16).toString('hex');

    await db
      .update(users)
      .set({
        passwordHash: newPasswordHash,
        sessionVersion: newSessionVersion,
        activeSessionId: newSessionId,
      })
      .where(eq(users.id, authResult.user.id));

    // Immediately invalidate the old password hash from the HMAC verification cache
    invalidatePasswordVerificationCache(oldPasswordHash);

    await recordAuditLog({
      actorUserId: authResult.user.id,
      actorUsername: authResult.user.displayUsername,
      action: 'PLAYER_PASSWORD_CHANGED',
      ipAddress: ip,
    });

    const token = signSessionToken({
      userId: authResult.user.id,
      uid: authResult.user.uid,
      username: authResult.user.displayUsername,
      role: 'player',
      sessionVersion: newSessionVersion,
      sessionId: newSessionId,
    });

    const res = NextResponse.json({ ok: true, sessionToken: token });
    setCrossContextSessionCookie(res, PLAYER_COOKIE_NAME, token, 60 * 60 * 24 * 7);
    return res;
  }

  // 7. REQUEST PASSWORD RESET (By Player when unauthenticated)
  if (action === 'request_password_reset') {
    const rl = checkRateLimit(`pwd_reset:${ip}`, 15, 300); // 15 attempts per 5 mins
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `Too many attempts. Please wait ${rl.retryAfterSeconds}s.` },
        { status: 429 }
      );
    }

    const rawUsername = String(body?.username || '').trim();
    const rawPhone = String(body?.phone || '').trim();
    const rawNotes = String(body?.notes || '').trim();

    if (!rawUsername && !rawPhone) {
      return NextResponse.json(
        { error: 'Please enter your username or registered phone number.' },
        { status: 400 }
      );
    }

    let matchedUser = null;
    if (rawUsername) {
      const normalizedLookup = rawUsername.replace(/\s+/g, ' ').trim().toLowerCase();
      const lookupPhone9 = extractPhoneSuffix9(normalizedLookup);
      const found = await db
        .select()
        .from(users)
        .where(
          or(
            eq(users.username, normalizedLookup),
            sql`REGEXP_REPLACE(LOWER(TRIM(${users.displayUsername})), '\\s+', ' ', 'g') = ${normalizedLookup}`,
            sql`LOWER(TRIM(${users.email})) = ${normalizedLookup}`,
            ...(lookupPhone9
              ? [sql`RIGHT(REGEXP_REPLACE(COALESCE(${users.phone}, ''), '[^0-9]', '', 'g'), 9) = ${lookupPhone9}`]
              : [])
          )
        );
      if (found.length > 0 && found[0].role === 'player') {
        matchedUser = found[0];
      }
    }

    if (!matchedUser && rawPhone) {
      const phone9 = extractPhoneSuffix9(rawPhone);
      const allUsers = await db.select().from(users).where(eq(users.role, 'player'));
      const foundByPhone = allUsers.find((u) => {
        if (!u.phone) return false;
        if (phone9 && extractPhoneSuffix9(u.phone) === phone9) return true;
        return u.phone.replace(/[\s\-\+]/g, '').includes(rawPhone.replace(/[\s\-\+]/g, ''));
      });
      if (foundByPhone) {
        matchedUser = foundByPhone;
      }
    }

    const inserted = await db
      .insert(passwordResets)
      .values({
        userId: matchedUser ? matchedUser.id : null,
        username: matchedUser ? matchedUser.displayUsername : rawUsername || rawPhone,
        phone: rawPhone || matchedUser?.phone || null,
        notes: rawNotes ? rawNotes.slice(0, 500) : null,
        status: 'PENDING',
      })
      .returning();

    const createdReq = inserted[0];

    await recordAuditLog({
      actorUsername: matchedUser?.displayUsername || rawUsername || rawPhone,
      targetUserId: matchedUser?.id,
      targetUsername: matchedUser?.displayUsername,
      action: 'PASSWORD_RESET_REQUESTED',
      reason: `Reset request #${createdReq.id} submitted. Phone: ${rawPhone || 'N/A'}. Notes: ${rawNotes || 'None'}`,
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      requestId: createdReq.id,
      message: 'የይለፍ ቃል መቀየሪያ ጥያቄዎ ለአድሚን ደርሷል። አድሚኑ እንደገመገመ አዲስ ጊዜያዊ የይለፍ ቃል ይደርስዎታል!',
    });
  }

  return NextResponse.json({ error: 'Unknown auth action' }, { status: 400 });
}
