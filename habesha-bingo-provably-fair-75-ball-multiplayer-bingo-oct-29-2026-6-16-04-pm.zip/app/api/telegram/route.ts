import { NextRequest, NextResponse } from 'next/server';
import {
  TELEGRAM_BOT_TOKEN,
  TELEGRAM_BOT_USERNAME,
  TELEGRAM_WEBAPP_URL,
  TELEGRAM_MENU_BUTTON_TEXT,
  configureTelegramBotIntegration,
  handleTelegramCommandUpdate,
  pollAndProcessTelegramBotCommands,
  sendTelegramWelcomeNotification,
} from '@/src/lib/telegram';

export const dynamic = 'force-dynamic';

/**
 * GET /api/telegram
 * Programmatically configures the Telegram Bot Menu Button ("Play Bingo 🎲" -> https://winner-bingo.ai.studio),
 * registers /start commands, and processes any pending /start messages from Telegram.
 */
export async function GET() {
  try {
    const [setupResult, pollResult] = await Promise.all([
      configureTelegramBotIntegration(),
      pollAndProcessTelegramBotCommands(),
    ]);

    return NextResponse.json(
      {
        ok: true,
        botUsername: `@${TELEGRAM_BOT_USERNAME}`,
        webAppUrl: TELEGRAM_WEBAPP_URL,
        menuButtonText: TELEGRAM_MENU_BUTTON_TEXT,
        setup: setupResult,
        polling: pollResult,
      },
      { status: 200 }
    );
  } catch (err: any) {
    return NextResponse.json(
      {
        ok: false,
        error: err?.message || 'Failed to run Telegram bot setup and command listener.',
      },
      { status: 500 }
    );
  }
}

/**
 * POST /api/telegram
 * Supports:
 * 1. Incoming Telegram Bot Webhook updates (e.g. /start, /play, /help commands)
 * 2. Explicit setup/polling triggers ({ action: 'setup' })
 * 3. Automated login welcome notifications ({ username, chatId, message })
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));

    if (!TELEGRAM_BOT_TOKEN) {
      return NextResponse.json(
        { ok: false, error: 'Telegram Bot Token is missing.' },
        { status: 400 }
      );
    }

    // 1. Check if this POST request is a Telegram Webhook Update (has update_id or message.chat)
    if (
      typeof body?.update_id === 'number' ||
      (body?.message && typeof body?.message === 'object' && body?.message?.chat?.id)
    ) {
      const commandResult = await handleTelegramCommandUpdate(body);
      return NextResponse.json({ ok: true, webhook: true, ...commandResult }, { status: 200 });
    }

    // 2. Check if this is an explicit bot menu configuration / polling request
    if (body?.action === 'setup' || body?.action === 'poll') {
      const [setupResult, pollResult] = await Promise.all([
        configureTelegramBotIntegration(body?.chatId),
        pollAndProcessTelegramBotCommands(),
      ]);
      return NextResponse.json(
        {
          ok: true,
          botUsername: `@${TELEGRAM_BOT_USERNAME}`,
          webAppUrl: TELEGRAM_WEBAPP_URL,
          menuButtonText: TELEGRAM_MENU_BUTTON_TEXT,
          setup: setupResult,
          polling: pollResult,
        },
        { status: 200 }
      );
    }

    // 3. Automated Login Welcome Notification
    const username = String(body.username || 'ተጫዋች').trim();
    const customMessage = typeof body.message === 'string' ? body.message.trim() : undefined;
    const chatId = body.chatId ? String(body.chatId).trim() : undefined;

    const result = await sendTelegramWelcomeNotification({
      username,
      chatId,
      message: customMessage,
    });

    return NextResponse.json(result, { status: 200 });
  } catch (err: any) {
    return NextResponse.json(
      {
        ok: false,
        error: err?.message || 'Unexpected error in Telegram API route.',
      },
      { status: 500 }
    );
  }
}
