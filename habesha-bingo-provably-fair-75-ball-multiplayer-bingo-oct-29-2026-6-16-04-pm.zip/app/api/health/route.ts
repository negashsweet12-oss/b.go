import { NextResponse } from 'next/server';
import { ensureInitialDataSeeded } from '@/src/db/users';
import { isMaintenanceModeEnabled } from '@/src/lib/game-coordinator';
import { reconcileAllWallets } from '@/src/lib/ledger';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await ensureInitialDataSeeded();
    const maintenance = await isMaintenanceModeEnabled();
    const reconciliation = await reconcileAllWallets();

    return NextResponse.json({
      status: 'ok',
      service: 'habesha-bingo-server',
      serverTimeUtc: new Date().toISOString(),
      defaultTimezone: process.env.DEFAULT_TIMEZONE || 'Africa/Addis_Ababa',
      maintenanceMode: maintenance,
      ledgerReconciled: reconciliation.driftCount === 0,
      rng: 'CSPRNG + HMAC-SHA256 Commit-Reveal',
    });
  } catch (error: any) {
    console.error('Health check failed:', error);
    return NextResponse.json(
      {
        status: 'degraded',
        serverTimeUtc: new Date().toISOString(),
        error: 'Service health check encountered an issue',
      },
      { status: 503 }
    );
  }
}
