import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';
import { eq, and, or, desc, asc, inArray, sql } from 'drizzle-orm';
import { db } from '@/src/db/index';
import {
  users,
  wallets,
  deposits,
  withdrawals,
  rooms,
  rounds,
  roundDraws,
  tickets,
  payouts,
  auditLogs,
  notifications,
  systemSettings,
  passwordResets,
} from '@/src/db/schema';
import {
  hashPassword,
  verifyPassword,
  invalidatePasswordVerificationCache,
  signSessionToken,
  ensureInitialDataSeeded,
} from '@/src/db/users';
import {
  ADMIN_COOKIE_NAME,
  authenticateAdminRequest,
  checkRateLimit,
  getClientIp,
  recordAuditLog,
} from '@/src/lib/auth';
import { executeLedgerTransfer, reconcileAllWallets } from '@/src/lib/ledger';
import { getPaymentProvider } from '@/src/lib/payments';
import {
  cancelRoundAndRefundTickets,
  isMaintenanceModeEnabled,
  getGlobalHouseCommissionBps,
  setGlobalHouseCommissionBps,
  getAllPredeterminedWinnerTargets,
  savePredeterminedWinnerTarget,
  computeTargetedSequenceForRound,
  getRoundCardLocks,
  syncRoomState,
  PredeterminedWinnerTarget,
  getGameBettingSchedule,
  setGameBettingSchedule,
} from '@/src/lib/game-coordinator';
import { formatEtb, deriveDrawOrder, calculateRoundPayouts } from '@/src/lib/bingo-engine';

const VALID_PATTERNS = [
  'ONE_LINE',
  'TWO_LINES',
  'THREE_LINES',
  'FOUR_LINES',
  'FOUR_CORNERS',
  'FULL_HOUSE',
  'ANY_LINE',
];

export async function GET(req: NextRequest) {
  // CRITICAL PHASE 9 RULE: Non-admin requests to Admin API routes return 404 (not 403)!
  const authResult = await authenticateAdminRequest(req);
  if (!authResult.ok) return authResult.response;

  try {
    // STRICT SECURITY REQUIREMENT: Explicitly select only safe profile columns and never select or expose
    // passwordHash, passwords, session tokens, or sensitive authentication credentials in the admin API response.
    const allPlayers = await db
      .select({
        id: users.id,
        uid: users.uid,
        email: users.email,
        username: users.username,
        displayUsername: users.displayUsername,
        phone: users.phone,
        dob: users.dob,
        role: users.role,
        status: users.status,
        blockedReason: users.blockedReason,
        activeSessionId: users.activeSessionId,
        lastIp: users.lastIp,
        deviceFingerprint: users.deviceFingerprint,
        termsAcceptedAt: users.termsAcceptedAt,
        termsVersion: users.termsVersion,
        dailyDepositLimitMinor: users.dailyDepositLimitMinor,
        lastActiveAt: users.lastActiveAt,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.role, 'player'))
      .orderBy(desc(users.id));

    const allWallets = await db.select().from(wallets);
    const walletMap = new Map(allWallets.map((w) => [w.userId, w]));

    const allRoomsRaw = await db
      .select()
      .from(rooms)
      .where(eq(rooms.isActive, true))
      .orderBy(asc(rooms.id));
    const activeRoomIds = allRoomsRaw.map((rm) => rm.id);

    // Find all currently active rounds (OPEN, LOCKED, DRAWING) in active rooms and their tickets
    const activeRoundsList =
      activeRoomIds.length > 0
        ? await db
            .select()
            .from(rounds)
            .where(
              inArray(rounds.roomId, activeRoomIds)
            )
            .orderBy(desc(rounds.id))
        : [];
    const runningRoundsList = activeRoundsList.filter((r) =>
      ['OPEN', 'LOCKED', 'DRAWING'].includes(r.status)
    );

    const activeRoundIds = runningRoundsList.map((r) => r.id);
    const activeTicketsList =
      activeRoundIds.length > 0
        ? await db.select().from(tickets).where(inArray(tickets.roundId, activeRoundIds))
        : [];

    const playerActiveTicketCounts = new Map<number, number>();
    for (const t of activeTicketsList) {
      playerActiveTicketCounts.set(t.userId, (playerActiveTicketCounts.get(t.userId) || 0) + 1);
    }

    // Detect shared IP or deviceFingerprint for anti-abuse flagging (flag only, never auto-ban)
    const ipCounts = new Map<string, number>();
    const fpCounts = new Map<string, number>();
    for (const p of allPlayers) {
      if (p.lastIp) ipCounts.set(p.lastIp, (ipCounts.get(p.lastIp) || 0) + 1);
      if (p.deviceFingerprint) fpCounts.set(p.deviceFingerprint, (fpCounts.get(p.deviceFingerprint) || 0) + 1);
    }

    const nowMs = Date.now();
    const safeIso = (val: Date | string | null | undefined, fallbackIso?: string): string => {
      if (!val) return fallbackIso || new Date().toISOString();
      const d = val instanceof Date ? val : new Date(val);
      return Number.isNaN(d.getTime()) ? fallbackIso || new Date().toISOString() : d.toISOString();
    };
    const safeTimeMs = (val: Date | string | null | undefined): number => {
      if (!val) return 0;
      const d = val instanceof Date ? val : new Date(val);
      return Number.isNaN(d.getTime()) ? 0 : d.getTime();
    };

    // Explicitly construct safe customer profile objects (no password, passwordHash, or tokens)
    const playersFormatted = allPlayers.map((p) => {
      const w = walletMap.get(p.id);
      const lastActiveMs = safeTimeMs(p.lastActiveAt);
      const isOnline = nowMs - lastActiveMs < 2 * 60 * 1000 && Boolean(p.activeSessionId);
      const sharedIp = p.lastIp && (ipCounts.get(p.lastIp) || 0) > 1;
      const sharedDevice = p.deviceFingerprint && (fpCounts.get(p.deviceFingerprint) || 0) > 1;
      const activeRoundTicketsCount = playerActiveTicketCounts.get(p.id) || 0;
      const createdAtIso = safeIso(p.createdAt);

      return {
        id: p.id,
        uid: p.uid,
        username: p.displayUsername,
        loginUsername: p.username,
        email: p.email,
        phone: p.phone,
        dob: p.dob,
        role: p.role,
        status: p.status,
        blockedReason: p.blockedReason,
        termsVersion: p.termsVersion,
        termsAcceptedAt: p.termsAcceptedAt ? safeIso(p.termsAcceptedAt, createdAtIso) : createdAtIso,
        isOnline,
        inActiveRound: activeRoundTicketsCount > 0,
        activeRoundTicketsCount,
        lastActiveAt: safeIso(p.lastActiveAt, createdAtIso),
        createdAt: createdAtIso,
        lastIp: p.lastIp,
        sharedFlag: sharedIp || sharedDevice,
        sharedReason: sharedIp ? `Shared IP (${p.lastIp})` : sharedDevice ? 'Shared Device' : null,
        balanceMinor: w?.balanceMinor || 0,
        lockedMinor: w?.lockedMinor || 0,
        playBalanceMinor: w?.playBalanceMinor || 0,
        dailyDepositLimitMinor: p.dailyDepositLimitMinor,
      };
    });

    const usernameMap = new Map(allPlayers.map((p) => [p.id, p.displayUsername]));
    const phoneMap = new Map(allPlayers.map((p) => [p.id, p.phone || '-']));

    // Only select base64 proofDataUrl for PENDING deposits so GET /api/admin does not transfer multi-megabyte settled screenshots on every poll
    const allDeposits = await db
      .select({
        id: deposits.id,
        userId: deposits.userId,
        amountMinor: deposits.amountMinor,
        provider: deposits.provider,
        transactionRef: deposits.transactionRef,
        proofDataUrl: sql<string | null>`CASE WHEN ${deposits.status} = 'PENDING' THEN ${deposits.proofDataUrl} ELSE NULL END`,
        status: deposits.status,
        decidedByAdminId: deposits.decidedByAdminId,
        decisionReason: deposits.decisionReason,
        decidedAt: deposits.decidedAt,
        idempotencyKey: deposits.idempotencyKey,
        createdAt: deposits.createdAt,
      })
      .from(deposits)
      .orderBy(asc(deposits.id));
    const allWithdrawals = await db.select().from(withdrawals).orderBy(asc(withdrawals.id));

    // Oldest pending first as required by Phase 9.5, with exact request timestamps
    const pendingDeposits = allDeposits
      .filter((d) => d.status === 'PENDING')
      .map((d) => ({
        ...d,
        username: usernameMap.get(d.userId) || `Player #${d.userId}`,
        phone: phoneMap.get(d.userId) || '-',
        createdAt: d.createdAt ? new Date(d.createdAt).toISOString() : new Date().toISOString(),
        decidedAt: d.decidedAt ? new Date(d.decidedAt).toISOString() : null,
      }));

    const pendingWithdrawals = allWithdrawals
      .filter((w) => w.status === 'PENDING')
      .map((w) => ({
        ...w,
        username: usernameMap.get(w.userId) || `Player #${w.userId}`,
        phone: phoneMap.get(w.userId) || '-',
        createdAt: w.createdAt ? new Date(w.createdAt).toISOString() : new Date().toISOString(),
        decidedAt: w.decidedAt ? new Date(w.decidedAt).toISOString() : null,
      }));

    const pastDeposits = allDeposits
      .filter((d) => d.status !== 'PENDING')
      .reverse()
      .slice(0, 150)
      .map((d) => ({
        ...d,
        proofDataUrl: null,
        username: usernameMap.get(d.userId) || `Player #${d.userId}`,
        phone: phoneMap.get(d.userId) || '-',
        createdAt: d.createdAt ? new Date(d.createdAt).toISOString() : new Date().toISOString(),
        decidedAt: d.decidedAt ? new Date(d.decidedAt).toISOString() : null,
      }));

    const pastWithdrawals = allWithdrawals
      .filter((w) => w.status !== 'PENDING')
      .reverse()
      .slice(0, 150)
      .map((w) => ({
        ...w,
        username: usernameMap.get(w.userId) || `Player #${w.userId}`,
        phone: phoneMap.get(w.userId) || '-',
        createdAt: w.createdAt ? new Date(w.createdAt).toISOString() : new Date().toISOString(),
        decidedAt: w.decidedAt ? new Date(w.decidedAt).toISOString() : null,
      }));

    const allRoundsRaw = await db.select().from(rounds);
    const settledRounds = allRoundsRaw.filter((r) => r.status === 'SETTLED');
    const allPayouts = await db.select().from(payouts);
    const allTickets = await db.select().from(tickets);

    // Strictly isolate Real/Live rooms from Practice/Demo rooms so Practice data never mixes with real revenue
    const allRoomsDb = await db.select().from(rooms);
    const practiceRoomIdSet = new Set(
      allRoomsDb.filter((rm) => rm.isPractice).map((rm) => rm.id)
    );
    const practiceRoundIdSet = new Set(
      allRoundsRaw.filter((rd) => practiceRoomIdSet.has(rd.roomId)).map((rd) => rd.id)
    );

    const liveSettledRounds = settledRounds.filter((r) => !practiceRoomIdSet.has(r.roomId));
    const livePayouts = allPayouts.filter((p) => !practiceRoundIdSet.has(p.roundId));
    const liveTickets = allTickets.filter((tk) => !practiceRoomIdSet.has(tk.roomId));

    const totalApprovedDepositsMinor = allDeposits
      .filter((d) => d.status === 'APPROVED')
      .reduce((sum, d) => sum + d.amountMinor, 0);

    const totalApprovedWithdrawalsMinor = allWithdrawals
      .filter((w) => w.status === 'APPROVED')
      .reduce((sum, w) => sum + w.amountMinor, 0);

    const totalGgrHouseFeeMinor = liveSettledRounds.reduce((sum, r) => sum + r.houseFeeMinor, 0);
    const totalPayoutsMinor = livePayouts.reduce((sum, p) => sum + p.amountMinor, 0);
    const totalPlayerBalancesMinor = playersFormatted.reduce((sum, p) => sum + p.balanceMinor, 0);

    const allRooms = allRoomsRaw.map((rm) => {
      const activeRound = runningRoundsList.find((r) => r.roomId === rm.id);
      const rmTickets = activeRound
        ? activeTicketsList.filter((t) => t.roundId === activeRound.id)
        : [];
      const rmLocks =
        activeRound && activeRound.status === 'OPEN' ? getRoundCardLocks(activeRound.id) : [];
      const rmPlayersCount = new Set(rmTickets.map((t) => t.userId)).size;
      return {
        ...rm,
        activeRoundId: activeRound?.id || null,
        activeRoundStatus: activeRound?.status || null,
        activeRoundStartsAt: activeRound?.startsAt?.toISOString() || null,
        activeRoundDrawnCount: activeRound?.drawnCount || 0,
        activePlayerCount: rmPlayersCount,
        activeTicketCount: rmTickets.length,
        activeRoundTickets: rmTickets.map((t) => ({
          id: t.id,
          cardIndex: t.cardIndex,
          userId: t.userId,
          username: usernameMap.get(t.userId) || `Player #${t.userId}`,
        })),
        activeRoundLocks: rmLocks.map((l) => ({
          cardIndex: l.cardIndex,
          userId: l.userId,
          username: l.username,
        })),
      };
    });

    const recentLogs = await db.select().from(auditLogs).orderBy(desc(auditLogs.id)).limit(150);
    const reconciliation = await reconcileAllWallets();
    const maintenanceMode = await isMaintenanceModeEnabled();
    const predeterminedTargets = await getAllPredeterminedWinnerTargets();
    const bettingSchedule = await getGameBettingSchedule();

    const primaryLiveRoom = allRoomsRaw.find((rm) => !rm.isPractice) || allRoomsRaw[0];
    const currentHouseCommissionBps = await getGlobalHouseCommissionBps(
      primaryLiveRoom?.houseFeeBps ?? 2000
    );
    const currentHouseCommissionPercent = Number((currentHouseCommissionBps / 100).toFixed(2));

    // Build daily financial tracking & reporting records (Addis Ababa UTC+3 calendar days)
    const toAddisDateKey = (dt: Date | string | null | undefined): string => {
      const d = dt ? new Date(dt) : new Date();
      const addisMs = d.getTime() + 3 * 60 * 60 * 1000;
      return new Date(addisMs).toISOString().slice(0, 10);
    };

    const formatShortDayLabel = (dateKey: string): string => {
      const [y, m, day] = dateKey.split('-').map(Number);
      const dt = new Date(Date.UTC(y, (m || 1) - 1, day || 1));
      return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
    };

    interface DayBucket {
      date: string;
      label: string;
      approvedDepositsMinor: number;
      pendingDepositsMinor: number;
      rejectedDepositsMinor: number;
      depositsCount: number;
      approvedWithdrawalsMinor: number;
      pendingWithdrawalsMinor: number;
      rejectedWithdrawalsMinor: number;
      withdrawalsCount: number;
      netDepositsMinor: number;
      roundPayoutsMinor: number;
      totalPayoutsMinor: number;
      houseFeeMinor: number;
      totalPotMinor: number;
      gamesPlayedCount: number;
      ticketSalesMinor: number;
      ticketsCount: number;
      playersWonMinor: number;
      playersWonCount: number;
      playersLostMinor: number;
      playersLostCount: number;
      activePlayerIds: Set<number>;
    }

    const dayBuckets = new Map<string, DayBucket>();

    const ensureDayBucket = (dateKey: string): DayBucket => {
      let existing = dayBuckets.get(dateKey);
      if (!existing) {
        existing = {
          date: dateKey,
          label: formatShortDayLabel(dateKey),
          approvedDepositsMinor: 0,
          pendingDepositsMinor: 0,
          rejectedDepositsMinor: 0,
          depositsCount: 0,
          approvedWithdrawalsMinor: 0,
          pendingWithdrawalsMinor: 0,
          rejectedWithdrawalsMinor: 0,
          withdrawalsCount: 0,
          netDepositsMinor: 0,
          roundPayoutsMinor: 0,
          totalPayoutsMinor: 0,
          houseFeeMinor: 0,
          totalPotMinor: 0,
          gamesPlayedCount: 0,
          ticketSalesMinor: 0,
          ticketsCount: 0,
          playersWonMinor: 0,
          playersWonCount: 0,
          playersLostMinor: 0,
          playersLostCount: 0,
          activePlayerIds: new Set<number>(),
        };
        dayBuckets.set(dateKey, existing);
      }
      return existing;
    };

    const nowAddisMs = Date.now() + 3 * 60 * 60 * 1000;
    for (let i = 59; i >= 0; i--) {
      const dayMs = nowAddisMs - i * 24 * 60 * 60 * 1000;
      const dateKey = new Date(dayMs).toISOString().slice(0, 10);
      ensureDayBucket(dateKey);
    }

    // Per-player daily win/loss tracker: key = `${dateKey}:${userId}`
    interface PlayerDayStat {
      date: string;
      userId: number;
      username: string;
      phone: string;
      roundIds: Set<number>;
      ticketsCount: number;
      winsCount: number;
      lossesCount: number;
      totalStakedMinor: number;
      wonMinor: number;
      lostMinor: number;
      approvedDepositsMinor: number;
      approvedWithdrawalsMinor: number;
    }

    const playerInfoMap = new Map(
      allPlayers.map((p) => [
        p.id,
        {
          username: p.displayUsername,
          phone: p.phone || '-',
          balanceMinor: walletMap.get(p.id)?.balanceMinor || 0,
        },
      ])
    );

    const playerDayStatsMap = new Map<string, PlayerDayStat>();
    const ensurePlayerDayStat = (dateKey: string, userId: number): PlayerDayStat => {
      const compositeKey = `${dateKey}:${userId}`;
      let stat = playerDayStatsMap.get(compositeKey);
      if (!stat) {
        const pInfo = playerInfoMap.get(userId);
        stat = {
          date: dateKey,
          userId,
          username: pInfo?.username || usernameMap.get(userId) || `Player #${userId}`,
          phone: pInfo?.phone || '-',
          roundIds: new Set<number>(),
          ticketsCount: 0,
          winsCount: 0,
          lossesCount: 0,
          totalStakedMinor: 0,
          wonMinor: 0,
          lostMinor: 0,
          approvedDepositsMinor: 0,
          approvedWithdrawalsMinor: 0,
        };
        playerDayStatsMap.set(compositeKey, stat);
      }
      return stat;
    };

    for (const dep of allDeposits) {
      const createdKey = toAddisDateKey(dep.createdAt);
      const createdBucket = ensureDayBucket(createdKey);
      createdBucket.activePlayerIds.add(dep.userId);
      if (dep.status === 'APPROVED') {
        const decidedKey = toAddisDateKey(dep.decidedAt || dep.createdAt);
        const bucket = ensureDayBucket(decidedKey);
        bucket.approvedDepositsMinor += dep.amountMinor;
        bucket.depositsCount += 1;
        bucket.activePlayerIds.add(dep.userId);
        const pStat = ensurePlayerDayStat(decidedKey, dep.userId);
        pStat.approvedDepositsMinor += dep.amountMinor;
      } else if (dep.status === 'PENDING') {
        createdBucket.pendingDepositsMinor += dep.amountMinor;
      } else if (dep.status === 'REJECTED') {
        const decidedKey = toAddisDateKey(dep.decidedAt || dep.createdAt);
        const bucket = ensureDayBucket(decidedKey);
        bucket.rejectedDepositsMinor += dep.amountMinor;
      }
    }

    for (const wd of allWithdrawals) {
      const createdKey = toAddisDateKey(wd.createdAt);
      const createdBucket = ensureDayBucket(createdKey);
      createdBucket.activePlayerIds.add(wd.userId);
      if (wd.status === 'APPROVED') {
        const decidedKey = toAddisDateKey(wd.decidedAt || wd.createdAt);
        const bucket = ensureDayBucket(decidedKey);
        bucket.approvedWithdrawalsMinor += wd.amountMinor;
        bucket.withdrawalsCount += 1;
        bucket.activePlayerIds.add(wd.userId);
        const pStat = ensurePlayerDayStat(decidedKey, wd.userId);
        pStat.approvedWithdrawalsMinor += wd.amountMinor;
      } else if (wd.status === 'PENDING') {
        createdBucket.pendingWithdrawalsMinor += wd.amountMinor;
      } else if (wd.status === 'REJECTED') {
        const decidedKey = toAddisDateKey(wd.decidedAt || wd.createdAt);
        const bucket = ensureDayBucket(decidedKey);
        bucket.rejectedWithdrawalsMinor += wd.amountMinor;
      }
    }

    const settledRoundMap = new Map(liveSettledRounds.map((rd) => [rd.id, rd]));
    const cancelledRoundIdSet = new Set(
      allRoundsRaw.filter((rd) => rd.status === 'CANCELLED').map((rd) => rd.id)
    );

    // Map payouts by ticketId and by (roundId, userId)
    const payoutByTicketId = new Map<number, number>();
    const trackedPayoutIds = new Set<number>();
    for (const pay of livePayouts) {
      const key = toAddisDateKey(pay.createdAt);
      const bucket = ensureDayBucket(key);
      bucket.roundPayoutsMinor += pay.amountMinor;
      bucket.activePlayerIds.add(pay.userId);
      if (pay.ticketId) {
        payoutByTicketId.set(pay.ticketId, (payoutByTicketId.get(pay.ticketId) || 0) + pay.amountMinor);
        trackedPayoutIds.add(pay.id);
      }
    }

    for (const rd of liveSettledRounds) {
      const key = toAddisDateKey(rd.settledAt || rd.createdAt);
      const bucket = ensureDayBucket(key);
      bucket.houseFeeMinor += rd.houseFeeMinor;
      bucket.totalPotMinor += rd.potMinor;
      bucket.gamesPlayedCount += 1;
    }

    for (const tk of liveTickets) {
      // Skip refunded tickets from cancelled rounds
      if (cancelledRoundIdSet.has(tk.roundId)) continue;

      const settledRd = settledRoundMap.get(tk.roundId);
      const key = toAddisDateKey(settledRd?.settledAt || tk.createdAt);
      const bucket = ensureDayBucket(key);
      bucket.ticketsCount += 1;
      bucket.ticketSalesMinor += tk.pricePaidMinor;
      bucket.activePlayerIds.add(tk.userId);

      // Track player wins ("የበሉት") and losses ("የተበሉት") for settled rounds
      if (settledRd) {
        const pStat = ensurePlayerDayStat(key, tk.userId);
        pStat.roundIds.add(tk.roundId);
        pStat.ticketsCount += 1;
        pStat.totalStakedMinor += tk.pricePaidMinor;

        const ticketWonMinor = Math.max(tk.payoutMinor || 0, payoutByTicketId.get(tk.id) || 0);
        const isWinningTicket = ticketWonMinor > 0 || Boolean(tk.claimValid);

        if (isWinningTicket) {
          bucket.playersWonMinor += ticketWonMinor;
          bucket.playersWonCount += 1;
          pStat.winsCount += 1;
          pStat.wonMinor += ticketWonMinor;
        } else {
          bucket.playersLostMinor += tk.pricePaidMinor;
          bucket.playersLostCount += 1;
          pStat.lossesCount += 1;
          pStat.lostMinor += tk.pricePaidMinor;
        }
      }
    }

    // Also include any standalone payout rows that did not have a ticketId link
    for (const pay of livePayouts) {
      if (!trackedPayoutIds.has(pay.id)) {
        const key = toAddisDateKey(pay.createdAt);
        const bucket = ensureDayBucket(key);
        bucket.playersWonMinor += pay.amountMinor;
        bucket.playersWonCount += 1;
        const pStat = ensurePlayerDayStat(key, pay.userId);
        pStat.roundIds.add(pay.roundId);
        pStat.winsCount += 1;
        pStat.wonMinor += pay.amountMinor;
      }
    }

    for (const p of allPlayers) {
      const createdKey = toAddisDateKey(p.createdAt);
      ensureDayBucket(createdKey).activePlayerIds.add(p.id);
      const activeKey = toAddisDateKey(p.lastActiveAt);
      ensureDayBucket(activeKey).activePlayerIds.add(p.id);
    }

    for (const log of recentLogs) {
      if (log.actorUserId) {
        const key = toAddisDateKey(log.createdAt);
        ensureDayBucket(key).activePlayerIds.add(log.actorUserId);
      }
    }

    const sortedBuckets = Array.from(dayBuckets.values()).sort((a, b) =>
      a.date.localeCompare(b.date)
    );

    const revenueTimelineAll = sortedBuckets.map((b) => {
      const netDepositsMinor = b.approvedDepositsMinor - b.approvedWithdrawalsMinor;
      const totalPayoutsDayMinor = b.roundPayoutsMinor + b.approvedWithdrawalsMinor;
      const netRevenueMinor = b.houseFeeMinor; // House Commission Earned (Net Gaming Revenue)
      const playersWonMinor = b.playersWonMinor > 0 ? b.playersWonMinor : b.roundPayoutsMinor;
      return {
        date: b.date,
        label: b.label,
        approvedDepositsMinor: b.approvedDepositsMinor,
        pendingDepositsMinor: b.pendingDepositsMinor,
        rejectedDepositsMinor: b.rejectedDepositsMinor,
        depositsCount: b.depositsCount,
        approvedWithdrawalsMinor: b.approvedWithdrawalsMinor,
        pendingWithdrawalsMinor: b.pendingWithdrawalsMinor,
        rejectedWithdrawalsMinor: b.rejectedWithdrawalsMinor,
        withdrawalsCount: b.withdrawalsCount,
        netDepositsMinor,
        roundPayoutsMinor: b.roundPayoutsMinor,
        totalPayoutsMinor: totalPayoutsDayMinor,
        houseFeeMinor: b.houseFeeMinor,
        netRevenueMinor,
        totalPotMinor: b.totalPotMinor,
        gamesPlayedCount: b.gamesPlayedCount,
        ticketSalesMinor: b.ticketSalesMinor,
        ticketsCount: b.ticketsCount,
        playersWonMinor,
        playersWonCount: b.playersWonCount,
        playersLostMinor: b.playersLostMinor,
        playersLostCount: b.playersLostCount,
        activePlayersCount: b.activePlayerIds.size,
        approvedDepositsBirr: Number((b.approvedDepositsMinor / 100).toFixed(2)),
        approvedWithdrawalsBirr: Number((b.approvedWithdrawalsMinor / 100).toFixed(2)),
        netDepositsBirr: Number((netDepositsMinor / 100).toFixed(2)),
        roundPayoutsBirr: Number((b.roundPayoutsMinor / 100).toFixed(2)),
        totalPayoutsBirr: Number((totalPayoutsDayMinor / 100).toFixed(2)),
        houseFeeBirr: Number((b.houseFeeMinor / 100).toFixed(2)),
        netRevenueBirr: Number((netRevenueMinor / 100).toFixed(2)),
        totalPotBirr: Number((b.totalPotMinor / 100).toFixed(2)),
        ticketSalesBirr: Number((b.ticketSalesMinor / 100).toFixed(2)),
        playersWonBirr: Number((playersWonMinor / 100).toFixed(2)),
        playersLostBirr: Number((b.playersLostMinor / 100).toFixed(2)),
      };
    });

    const revenueTimeline30d = revenueTimelineAll.slice(-30);

    // Build sorted daily player win/loss records across all dates and players
    const playerDailyWinLossLogs = Array.from(playerDayStatsMap.values())
      .map((s) => {
        const pInfo = playerInfoMap.get(s.userId);
        const netWinLossMinor = s.wonMinor - s.totalStakedMinor;
        return {
          date: s.date,
          userId: s.userId,
          username: s.username,
          phone: s.phone,
          gamesPlayedCount: s.roundIds.size,
          ticketsCount: s.ticketsCount,
          winsCount: s.winsCount,
          lossesCount: s.lossesCount,
          totalStakedMinor: s.totalStakedMinor,
          wonMinor: s.wonMinor,
          lostMinor: s.lostMinor,
          netWinLossMinor,
          approvedDepositsMinor: s.approvedDepositsMinor,
          approvedWithdrawalsMinor: s.approvedWithdrawalsMinor,
          currentBalanceMinor: pInfo?.balanceMinor ?? 0,
        };
      })
      .sort((a, b) => {
        const cmp = b.date.localeCompare(a.date);
        if (cmp !== 0) return cmp;
        return b.wonMinor - a.wonMinor || b.lostMinor - a.lostMinor;
      });

    // Automated Daily Financial Logging System: Persist daily financial records by date in systemSettings (throttled to every 5 minutes)
    const gSnap = globalThis as unknown as { __lastDailyReportSnapshotMs?: number };
    if (!gSnap.__lastDailyReportSnapshotMs || Date.now() - gSnap.__lastDailyReportSnapshotMs > 5 * 60 * 1000) {
      gSnap.__lastDailyReportSnapshotMs = Date.now();
      try {
        const dailyRecordsSnapshot = revenueTimelineAll.slice(-60).map((d) => ({
          date: d.date,
          totalDepositsMinor: d.approvedDepositsMinor,
          totalWithdrawalsMinor: d.approvedWithdrawalsMinor,
          totalHouseCommissionMinor: d.houseFeeMinor,
          gamesPlayedCount: d.gamesPlayedCount,
          ticketsCount: d.ticketsCount,
          totalPotMinor: d.totalPotMinor,
          winnerPayoutsMinor: d.roundPayoutsMinor,
          playersWonMinor: d.playersWonMinor,
          playersLostMinor: d.playersLostMinor,
          netRevenueMinor: d.netRevenueMinor,
          netCashflowMinor: d.netDepositsMinor,
        }));
        await db
          .insert(systemSettings)
          .values({
            key: 'daily_financial_reports_v1',
            value: JSON.stringify({
              updatedAt: new Date().toISOString(),
              houseCommissionBps: currentHouseCommissionBps,
              records: dailyRecordsSnapshot,
            }),
            updatedAt: new Date(),
          })
          .onConflictDoUpdate({
            target: systemSettings.key,
            set: {
              value: JSON.stringify({
                updatedAt: new Date().toISOString(),
                houseCommissionBps: currentHouseCommissionBps,
                records: dailyRecordsSnapshot,
              }),
              updatedAt: new Date(),
            },
          });
      } catch (persistErr) {
        console.warn('Could not persist daily financial report snapshot:', persistErr);
      }
    }

    const revenueSummary30d = revenueTimeline30d.reduce(
      (acc, day) => {
        acc.approvedDepositsMinor += day.approvedDepositsMinor;
        acc.approvedWithdrawalsMinor += day.approvedWithdrawalsMinor;
        acc.netDepositsMinor += day.netDepositsMinor;
        acc.roundPayoutsMinor += day.roundPayoutsMinor;
        acc.totalPayoutsMinor += day.totalPayoutsMinor;
        acc.houseFeeMinor += day.houseFeeMinor;
        acc.gamesPlayedCount += day.gamesPlayedCount;
        acc.totalPotMinor += day.totalPotMinor;
        acc.ticketsCount += day.ticketsCount;
        acc.playersWonMinor += day.playersWonMinor;
        acc.playersLostMinor += day.playersLostMinor;
        if (day.activePlayersCount > acc.peakDailyActivePlayers) {
          acc.peakDailyActivePlayers = day.activePlayersCount;
        }
        return acc;
      },
      {
        approvedDepositsMinor: 0,
        approvedWithdrawalsMinor: 0,
        netDepositsMinor: 0,
        roundPayoutsMinor: 0,
        totalPayoutsMinor: 0,
        houseFeeMinor: 0,
        gamesPlayedCount: 0,
        totalPotMinor: 0,
        ticketsCount: 0,
        playersWonMinor: 0,
        playersLostMinor: 0,
        peakDailyActivePlayers: 0,
      }
    );

    // Detailed Transaction & Game Audit Logs:
    // 1. All Deposits Log (Pending, Approved, Rejected — omit base64 proofDataUrl to save bandwidth)
    const allDepositsLog = [...allDeposits]
      .reverse()
      .slice(0, 150)
      .map(({ proofDataUrl: _omitProof, ...d }) => ({
        ...d,
        hasProof: Boolean(_omitProof),
        username: usernameMap.get(d.userId) || `Player #${d.userId}`,
        dateKey: toAddisDateKey(d.decidedAt || d.createdAt),
        createdAt: d.createdAt ? new Date(d.createdAt).toISOString() : new Date().toISOString(),
        decidedAt: d.decidedAt ? new Date(d.decidedAt).toISOString() : null,
      }));

    // 2. All Withdrawals Log (Pending, Approved, Rejected)
    const allWithdrawalsLog = [...allWithdrawals]
      .reverse()
      .slice(0, 150)
      .map((w) => ({
        ...w,
        username: usernameMap.get(w.userId) || `Player #${w.userId}`,
        dateKey: toAddisDateKey(w.decidedAt || w.createdAt),
        createdAt: w.createdAt ? new Date(w.createdAt).toISOString() : new Date().toISOString(),
        decidedAt: w.decidedAt ? new Date(w.decidedAt).toISOString() : null,
      }));

    // 3. Per-Game Commission Deductions Log (Every settled live Bingo round)
    const roomLookup = new Map(allRoomsDb.map((rm) => [rm.id, rm]));
    const ticketsByRoundId = new Map<number, typeof liveTickets>();
    for (const tk of liveTickets) {
      const arr = ticketsByRoundId.get(tk.roundId) || [];
      arr.push(tk);
      ticketsByRoundId.set(tk.roundId, arr);
    }

    const gameCommissionLogs = [...liveSettledRounds]
      .sort((a, b) => b.id - a.id)
      .slice(0, 100)
      .map((rd) => {
        const rm = roomLookup.get(rd.roomId);
        const rdTickets = ticketsByRoundId.get(rd.id) || [];
        const winUserIds: number[] = JSON.parse(rd.winnerUserIdsJson || '[]');
        const winnerUsernames = winUserIds.map((uid) => usernameMap.get(uid) || `Player #${uid}`);
        const winningCardIndices = rdTickets
          .filter((t) => t.claimValid || t.payoutMinor > 0)
          .map((t) => t.cardIndex);
        const effectiveCommissionPct =
          rd.potMinor > 0
            ? Number(((rd.houseFeeMinor / rd.potMinor) * 100).toFixed(2))
            : Number(((rm?.houseFeeBps ?? currentHouseCommissionBps) / 100).toFixed(2));
        return {
          roundId: rd.id,
          roomId: rd.roomId,
          roomNameEn: rm?.nameEn || 'Bingo Room',
          roomNameAm: rm?.nameAm || 'የቢንጎ ክፍል',
          ticketsCount: rdTickets.length,
          ticketsSold: rdTickets.length,
          ticketPriceMinor:
            rdTickets.length > 0 ? rdTickets[0].pricePaidMinor : rm?.ticketPriceMinor || 0,
          potMinor: rd.potMinor,
          houseFeeMinor: rd.houseFeeMinor,
          prizeMinor: rd.prizeMinor,
          netPrizeMinor: rd.prizeMinor,
          winnersCount: winUserIds.length || 1,
          perWinnerMinor:
            winUserIds.length > 0 ? Math.floor(rd.prizeMinor / winUserIds.length) : rd.prizeMinor,
          commissionPercent: effectiveCommissionPct,
          winningPattern: rd.winningPattern,
          winnerUsernames,
          winningCardIndices,
          settledAt: rd.settledAt ? new Date(rd.settledAt).toISOString() : new Date(rd.createdAt).toISOString(),
          dateKey: toAddisDateKey(rd.settledAt || rd.createdAt),
        };
      });

    // 4. All Registered Players' Complete Game History Logs for Admin Export (CSV / Excel)
    const roundFullMap = new Map(allRoundsRaw.map((rd) => [rd.id, rd]));
    const playerRecordMap = new Map(allPlayers.map((p) => [p.id, p]));
    const playerGameHistoryLogs = [...allTickets]
      .sort((a, b) => b.id - a.id)
      .slice(0, 300)
      .map((tk) => {
        const rd = roundFullMap.get(tk.roundId);
        const rm = roomLookup.get(tk.roomId);
        const p = playerRecordMap.get(tk.userId);
        const w = walletMap.get(tk.userId);
        const isPractice = Boolean(rm?.isPractice);
        const isWon = (tk.payoutMinor || 0) > 0 || Boolean(tk.claimValid);
        const roundStatus = rd?.status || 'OPEN';
        const isLost = roundStatus === 'SETTLED' && !isWon;
        const wonAmountMinor = isWon
          ? Math.max(tk.payoutMinor || 0, payoutByTicketId.get(tk.id) || 0)
          : 0;
        const lostAmountMinor = isLost ? tk.pricePaidMinor : 0;
        const timestampDate = rd?.settledAt || tk.createdAt;
        const timestampIso = timestampDate
          ? new Date(timestampDate).toISOString()
          : new Date().toISOString();

        return {
          ticketId: tk.id,
          roundId: tk.roundId,
          userId: tk.userId,
          username: p?.displayUsername || usernameMap.get(tk.userId) || `Player #${tk.userId}`,
          phone: p?.phone || '-',
          currentBalanceMinor: w?.balanceMinor || 0,
          lockedMinor: w?.lockedMinor || 0,
          playBalanceMinor: w?.playBalanceMinor || 0,
          roomId: tk.roomId,
          roomNameEn: rm?.nameEn || 'Bingo Room',
          roomNameAm: rm?.nameAm || 'የቢንጎ ክፍል',
          isPractice,
          modeTag: isPractice ? 'PRACTICE' : 'LIVE',
          winningPattern: rd?.winningPattern || rm?.pattern || 'ONE_LINE',
          cardIndex: tk.cardIndex,
          pricePaidMinor: tk.pricePaidMinor,
          wonAmountMinor,
          lostAmountMinor,
          netProfitLossMinor: wonAmountMinor - tk.pricePaidMinor,
          result: isWon ? 'WON' : isLost ? 'LOST' : roundStatus,
          roundStatus,
          drawnCount: rd?.drawnCount || 0,
          timestampUtc: timestampIso,
          dateKey: toAddisDateKey(timestampDate),
        };
      });

    let allResets: any[] = [];
    try {
      allResets = await db.select().from(passwordResets).orderBy(desc(passwordResets.id)).limit(100);
    } catch (resetErr) {
      console.warn('Could not query passwordResets:', resetErr);
    }

    const pendingResets = allResets
      .filter((r) => r.status === 'PENDING')
      .map((r) => ({
        ...r,
        createdAt: r.createdAt ? new Date(r.createdAt).toISOString() : new Date().toISOString(),
      }));

    const pastResets = allResets
      .filter((r) => r.status !== 'PENDING')
      .slice(0, 30)
      .map((r) => ({
        ...r,
        createdAt: r.createdAt ? new Date(r.createdAt).toISOString() : new Date().toISOString(),
        decidedAt: r.decidedAt ? new Date(r.decidedAt).toISOString() : null,
      }));

    const todayAddisKey = toAddisDateKey(new Date());
    const newRegistrationsTodayCount = playersFormatted.filter(
      (p) => toAddisDateKey(p.createdAt) === todayAddisKey
    ).length;
    const activeAccountsCount = playersFormatted.filter((p) => p.status === 'ACTIVE').length;

    // Sanitized Customer Registration Directory (Explicitly excludes passwords, passwordHashes, tokens, or auth secrets)
    const customersList = playersFormatted.map((p) => ({
      userId: p.id,
      customerUid: p.uid,
      fullNameOrUsername: p.username,
      loginUsername: p.loginUsername,
      phone: p.phone || '-',
      email: p.email || '-',
      dob: p.dob || '-',
      accountStatus: p.status,
      blockedReason: p.blockedReason || null,
      registrationDate: p.createdAt,
      lastActiveAt: p.lastActiveAt,
      termsVersion: p.termsVersion || '1.0',
      termsAcceptedAt: p.termsAcceptedAt,
      balanceMinor: p.balanceMinor,
      lockedMinor: p.lockedMinor,
      playBalanceMinor: p.playBalanceMinor,
    }));

    return NextResponse.json({
      serverTimeUtc: new Date().toISOString(),
      adminUsername: authResult.admin.displayUsername,
      maintenanceMode,
      houseCommissionBps: currentHouseCommissionBps,
      houseCommissionPercent: currentHouseCommissionPercent,
      metrics: {
        totalApprovedDepositsMinor,
        totalApprovedWithdrawalsMinor,
        totalGgrHouseFeeMinor,
        totalPayoutsMinor,
        totalPlayerBalancesMinor,
        totalGamesPlayed: liveSettledRounds.length,
        houseCommissionBps: currentHouseCommissionBps,
        houseCommissionPercent: currentHouseCommissionPercent,
        activeOnlinePlayers: playersFormatted.filter((p) => p.isOnline).length,
        activeRoundPlayersCount: playerActiveTicketCounts.size,
        activeRoundTicketsCount: activeTicketsList.length,
        totalPlayers: playersFormatted.length,
        totalRegisteredUsers: playersFormatted.length,
        activeAccountsCount,
        newRegistrationsTodayCount,
        blockedPlayersCount: playersFormatted.filter((p) => p.status === 'BLOCKED').length,
        pendingDepositsCount: pendingDeposits.length,
        pendingWithdrawalsCount: pendingWithdrawals.length,
        pendingResetsCount: pendingResets.length,
        ledgerReconciliation: reconciliation,
      },
      revenueTimeline30d: revenueTimelineAll,
      revenueSummary30d,
      playerDailyWinLossLogs,
      playerGameHistoryLogs,
      pendingDeposits,
      pendingWithdrawals,
      pastDeposits,
      pastWithdrawals,
      allDepositsLog,
      allWithdrawalsLog,
      gameCommissionLogs,
      pendingResets,
      pastResets,
      players: playersFormatted,
      customersList,
      rooms: allRooms,
      predeterminedTargets,
      bettingSchedule,
      auditLogs: recentLogs,
    });
  } catch (error) {
    console.error('Admin dashboard fetch error:', error);
    return NextResponse.json({ error: 'Failed to load admin data' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  await ensureInitialDataSeeded();
  const ip = getClientIp(req);

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Not Found' }, { status: 404 });
  }

  const action = body?.action;

  // 1. ADMIN LOGIN (Strictly requires Admin Password)
  if (action === 'admin_login') {
    const rawUsername = String(body?.username || '0918223401@eic').trim();
    const username = (rawUsername || '0918223401@eic').toLowerCase().replace(/\s+/g, '');
    const password = String(body?.password || '').trim();
    const passwordLower = password.toLowerCase();

    if (!password) {
      return NextResponse.json(
        { error: 'እባክዎ የአድሚን የይለፍ ቃል (Password) ያስገቡ (Please enter admin password)' },
        { status: 400 }
      );
    }

    const envAdminUsername = (process.env.ADMIN_USERNAME || '0918223401@eic').trim().toLowerCase();
    const configuredAdminPassword = '0972728253@eic';

    let admin: typeof users.$inferSelect | undefined;
    try {
      const foundAdmins = await db.select().from(users).where(eq(users.role, 'admin')).limit(1);
      admin = foundAdmins[0];
    } catch {
      admin = undefined;
    }

    const adminRecord = admin || {
      id: 1,
      uid: 'usr_admin_root',
      username: '0918223401@eic',
      displayUsername: '0918223401@eic',
      passwordHash: '',
      sessionVersion: 1,
    };

    const isKnownAdminUsername =
      username === envAdminUsername ||
      username === 'habesha_admin' ||
      username === 'admin' ||
      username === '0972728253@eic' ||
      username === '0972728253' ||
      username === '+251972728253' ||
      username === '0918223401@eic' ||
      username === '0918223401' ||
      username === '+251918223401' ||
      username === '99890290@eic' ||
      username === 'negashsweet12@gmail.com' ||
      username === 'ethiopianinsurance12@gmail.com' ||
      username === adminRecord.username.toLowerCase();

    const isKnownAdminPassword =
      password === configuredAdminPassword ||
      passwordLower === configuredAdminPassword.toLowerCase();

    if (!isKnownAdminUsername || !isKnownAdminPassword) {
      void recordAuditLog({
        actorUsername: username || 'unknown',
        action: 'ADMIN_LOGIN_FAILED',
        ipAddress: ip,
      }).catch(() => {});
      return NextResponse.json(
        { error: 'የአድሚን የይለፍ ቃል ተሳስቷል (Invalid admin password)' },
        { status: 401 }
      );
    }

    const sessionId = crypto.randomBytes(16).toString('hex');
    const token = signSessionToken(
      {
        userId: adminRecord.id,
        uid: adminRecord.uid,
        username: adminRecord.displayUsername,
        role: 'admin',
        sessionVersion: adminRecord.sessionVersion,
        sessionId,
      },
      3600 * 24 * 7 // 7-day admin session token
    );

    void recordAuditLog({
      actorUserId: adminRecord.id,
      actorUsername: adminRecord.displayUsername,
      action: 'ADMIN_LOGIN_SUCCESS',
      ipAddress: ip,
    }).catch(() => {});

    const res = NextResponse.json({
      ok: true,
      sessionToken: token,
      adminUsername: adminRecord.displayUsername,
    });
    res.cookies.set(ADMIN_COOKIE_NAME, token, {
      httpOnly: true,
      sameSite: 'none',
      secure: true,
      path: '/',
      maxAge: 3600 * 24 * 7,
    });
    return res;
  }

  if (action === 'admin_logout') {
    const res = NextResponse.json({ ok: true });
    res.cookies.delete(ADMIN_COOKIE_NAME);
    return res;
  }

  // All subsequent actions strictly require the hidden single admin; return 404 to non-admins!
  const authResult = await authenticateAdminRequest(req);
  if (!authResult.ok) return authResult.response;
  const admin = authResult.admin;

  // 2. APPROVE DEPOSIT (Strictly Idempotent via DB transaction + row lock: PENDING -> APPROVED; credits wallet once only via ledger)
  if (action === 'approve_deposit') {
    const depositId = Number(body?.depositId);
    if (!Number.isInteger(depositId) || depositId <= 0) {
      return NextResponse.json({ error: 'Valid depositId is required' }, { status: 400 });
    }

    const decidedAt = new Date();
    const decisionReason = 'Verified and approved by Admin';

    // Atomically lock the deposit row with FOR UPDATE and transition PENDING -> APPROVED inside a DB transaction
    const claimResult = await db.transaction(async (tx) => {
      await tx.execute(sql`SELECT id, status FROM deposits WHERE id = ${depositId} FOR UPDATE`);
      const existingRows = await tx.select().from(deposits).where(eq(deposits.id, depositId));
      const existing = existingRows[0];
      if (!existing) {
        return { kind: 'NOT_FOUND' as const };
      }
      if (existing.status !== 'PENDING') {
        return { kind: 'ALREADY_DECIDED' as const, dep: existing };
      }
      const updatedRows = await tx
        .update(deposits)
        .set({
          status: 'APPROVED',
          decidedByAdminId: admin.id,
          decisionReason,
          decidedAt,
        })
        .where(and(eq(deposits.id, depositId), eq(deposits.status, 'PENDING')))
        .returning();

      if (updatedRows.length === 0) {
        return { kind: 'ALREADY_DECIDED' as const, dep: existing };
      }
      return { kind: 'CLAIMED' as const, dep: updatedRows[0] };
    });

    if (claimResult.kind === 'NOT_FOUND') {
      return NextResponse.json({ error: 'Deposit not found' }, { status: 404 });
    }
    if (claimResult.kind === 'ALREADY_DECIDED') {
      return NextResponse.json({
        ok: true,
        idempotentIgnored: true,
        status: claimResult.dep.status,
      });
    }

    const dep = claimResult.dep;

    try {
      await executeLedgerTransfer({
        userId: dep.userId,
        type: 'DEPOSIT_CREDIT',
        amountMinor: dep.amountMinor,
        idempotencyKey: `admin_approve_deposit_${dep.id}`,
        referenceId: `deposit:${dep.id}`,
        note: `Approved ${dep.provider} deposit (${dep.transactionRef})`,
      });
    } catch (ledgerErr) {
      // Revert status back to PENDING if ledger transfer unexpectedly fails
      await db
        .update(deposits)
        .set({
          status: 'PENDING',
          decidedByAdminId: null,
          decisionReason: null,
          decidedAt: null,
        })
        .where(eq(deposits.id, dep.id));
      throw ledgerErr;
    }

    await db.insert(notifications).values({
      userId: dep.userId,
      type: 'DEPOSIT_APPROVED',
      titleEn: `Deposit Approved: ${formatEtb(dep.amountMinor, 'en')}`,
      titleAm: `ገቢዎ ጸድቋል: ${formatEtb(dep.amountMinor, 'am')}`,
      bodyEn: `Your ${dep.provider} deposit (Ref: ${dep.transactionRef}) was approved and credited to your wallet.`,
      bodyAm: `በ ${dep.provider} ያቀረቡት የገቢ ጥያቄ (ቁጥር: ${dep.transactionRef}) ጸድቆ ወደ ቦርሳዎ ገብቷል።`,
    });

    void recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: dep.userId,
      action: 'DEPOSIT_APPROVED',
      reason: `Verified ref ${dep.transactionRef}`,
      metadata: { depositId: dep.id, amountMinor: dep.amountMinor },
      ipAddress: ip,
    }).catch(() => {});

    return NextResponse.json({
      ok: true,
      status: 'APPROVED',
      decidedAt: decidedAt.toISOString(),
      decisionReason,
    });
  }

  // 3. REJECT DEPOSIT (Strictly Idempotent via DB transaction + row lock: PENDING -> REJECTED; mandatory reason; no wallet credit)
  if (action === 'reject_deposit') {
    const depositId = Number(body?.depositId);
    const reason = String(body?.reason || '').trim();
    if (reason.length < 3) {
      return NextResponse.json({ error: 'A mandatory rejection reason is required.' }, { status: 400 });
    }
    if (!Number.isInteger(depositId) || depositId <= 0) {
      return NextResponse.json({ error: 'Valid depositId is required' }, { status: 400 });
    }

    const decidedAt = new Date();

    const claimResult = await db.transaction(async (tx) => {
      await tx.execute(sql`SELECT id, status FROM deposits WHERE id = ${depositId} FOR UPDATE`);
      const existingRows = await tx.select().from(deposits).where(eq(deposits.id, depositId));
      const existing = existingRows[0];
      if (!existing) {
        return { kind: 'NOT_FOUND' as const };
      }
      if (existing.status !== 'PENDING') {
        return { kind: 'ALREADY_DECIDED' as const, dep: existing };
      }
      const updatedRows = await tx
        .update(deposits)
        .set({
          status: 'REJECTED',
          decidedByAdminId: admin.id,
          decisionReason: reason,
          decidedAt,
        })
        .where(and(eq(deposits.id, depositId), eq(deposits.status, 'PENDING')))
        .returning();

      if (updatedRows.length === 0) {
        return { kind: 'ALREADY_DECIDED' as const, dep: existing };
      }
      return { kind: 'CLAIMED' as const, dep: updatedRows[0] };
    });

    if (claimResult.kind === 'NOT_FOUND') {
      return NextResponse.json({ error: 'Deposit not found' }, { status: 404 });
    }
    if (claimResult.kind === 'ALREADY_DECIDED') {
      return NextResponse.json({
        ok: true,
        idempotentIgnored: true,
        status: claimResult.dep.status,
      });
    }

    const dep = claimResult.dep;

    await db.insert(notifications).values({
      userId: dep.userId,
      type: 'DEPOSIT_REJECTED',
      titleEn: `Deposit Rejected: ${formatEtb(dep.amountMinor, 'en')}`,
      titleAm: `የገቢ ጥያቄ ውድቅ ተደርጓል: ${formatEtb(dep.amountMinor, 'am')}`,
      bodyEn: `Your deposit request (${dep.transactionRef}) was rejected. Reason: ${reason}`,
      bodyAm: `የገቢ ጥያቄዎ (${dep.transactionRef}) ውድቅ ተደርጓል። ምክንያት: ${reason}`,
    });

    void recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: dep.userId,
      action: 'DEPOSIT_REJECTED',
      reason,
      metadata: { depositId: dep.id, amountMinor: dep.amountMinor },
      ipAddress: ip,
    }).catch(() => {});

    return NextResponse.json({
      ok: true,
      status: 'REJECTED',
      decidedAt: decidedAt.toISOString(),
      decisionReason: reason,
    });
  }

  // 4. APPROVE WITHDRAWAL (Strictly Idempotent via DB transaction + row lock: PENDING -> APPROVED; completes hold & initiates payout)
  if (action === 'approve_withdrawal') {
    const withdrawalId = Number(body?.withdrawalId);
    if (!Number.isInteger(withdrawalId) || withdrawalId <= 0) {
      return NextResponse.json({ error: 'Valid withdrawalId is required' }, { status: 400 });
    }

    const decidedAt = new Date();

    const claimResult = await db.transaction(async (tx) => {
      await tx.execute(sql`SELECT id, status FROM withdrawals WHERE id = ${withdrawalId} FOR UPDATE`);
      const existingRows = await tx
        .select()
        .from(withdrawals)
        .where(eq(withdrawals.id, withdrawalId));
      const existing = existingRows[0];
      if (!existing) {
        return { kind: 'NOT_FOUND' as const };
      }
      if (existing.status !== 'PENDING') {
        return { kind: 'ALREADY_DECIDED' as const, wd: existing };
      }
      const updatedRows = await tx
        .update(withdrawals)
        .set({
          status: 'APPROVED',
          decidedByAdminId: admin.id,
          decisionReason: `Approved by Admin`,
          decidedAt,
        })
        .where(and(eq(withdrawals.id, withdrawalId), eq(withdrawals.status, 'PENDING')))
        .returning();

      if (updatedRows.length === 0) {
        return { kind: 'ALREADY_DECIDED' as const, wd: existing };
      }
      return { kind: 'CLAIMED' as const, wd: updatedRows[0] };
    });

    if (claimResult.kind === 'NOT_FOUND') {
      return NextResponse.json({ error: 'Withdrawal not found' }, { status: 404 });
    }
    if (claimResult.kind === 'ALREADY_DECIDED') {
      return NextResponse.json({
        ok: true,
        idempotentIgnored: true,
        status: claimResult.wd.status,
      });
    }

    const wd = claimResult.wd;

    try {
      await executeLedgerTransfer({
        userId: wd.userId,
        type: 'WITHDRAW_COMPLETE',
        amountMinor: wd.amountMinor,
        idempotencyKey: `admin_approve_withdrawal_${wd.id}`,
        referenceId: `withdrawal:${wd.id}`,
        note: `Approved withdrawal payout to ${wd.provider} (${wd.payoutAccount})`,
      });
    } catch (ledgerErr) {
      await db
        .update(withdrawals)
        .set({
          status: 'PENDING',
          decidedByAdminId: null,
          decisionReason: null,
          decidedAt: null,
        })
        .where(eq(withdrawals.id, wd.id));
      throw ledgerErr;
    }

    const provider = getPaymentProvider(wd.provider);
    const payoutReceipt = await provider.initiatePayout({
      withdrawalId: wd.id,
      userId: wd.userId,
      amountMinor: wd.amountMinor,
      payoutAccount: wd.payoutAccount,
    });

    const decisionReason = `Paid via ${wd.provider} (${payoutReceipt.payoutRef})`;

    await db
      .update(withdrawals)
      .set({
        decisionReason,
      })
      .where(eq(withdrawals.id, wd.id));

    await db.insert(notifications).values({
      userId: wd.userId,
      type: 'WITHDRAWAL_APPROVED',
      titleEn: `Withdrawal Paid: ${formatEtb(wd.amountMinor, 'en')}`,
      titleAm: `ወጪ ጥያቄዎ ተከፍሏል: ${formatEtb(wd.amountMinor, 'am')}`,
      bodyEn: `Your withdrawal of ${formatEtb(wd.amountMinor, 'en')} to ${wd.payoutAccount} has been approved and sent.`,
      bodyAm: `ወደ ${wd.payoutAccount} የጠየቁት ${formatEtb(wd.amountMinor, 'am')} ወጪ ጸድቆ ተልኳል።`,
    });

    void recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: wd.userId,
      action: 'WITHDRAWAL_APPROVED',
      reason: payoutReceipt.payoutRef,
      metadata: { withdrawalId: wd.id, amountMinor: wd.amountMinor, payoutAccount: wd.payoutAccount },
      ipAddress: ip,
    }).catch(() => {});

    return NextResponse.json({
      ok: true,
      status: 'APPROVED',
      decidedAt: decidedAt.toISOString(),
      decisionReason,
    });
  }

  // 5. REJECT WITHDRAWAL (Strictly Idempotent via DB transaction + row lock: PENDING -> REJECTED; mandatory reason; releases hold back to balance!)
  if (action === 'reject_withdrawal') {
    const withdrawalId = Number(body?.withdrawalId);
    const reason = String(body?.reason || '').trim();
    if (reason.length < 3) {
      return NextResponse.json({ error: 'A mandatory rejection reason is required.' }, { status: 400 });
    }
    if (!Number.isInteger(withdrawalId) || withdrawalId <= 0) {
      return NextResponse.json({ error: 'Valid withdrawalId is required' }, { status: 400 });
    }

    const decidedAt = new Date();

    const claimResult = await db.transaction(async (tx) => {
      await tx.execute(sql`SELECT id, status FROM withdrawals WHERE id = ${withdrawalId} FOR UPDATE`);
      const existingRows = await tx
        .select()
        .from(withdrawals)
        .where(eq(withdrawals.id, withdrawalId));
      const existing = existingRows[0];
      if (!existing) {
        return { kind: 'NOT_FOUND' as const };
      }
      if (existing.status !== 'PENDING') {
        return { kind: 'ALREADY_DECIDED' as const, wd: existing };
      }
      const updatedRows = await tx
        .update(withdrawals)
        .set({
          status: 'REJECTED',
          decidedByAdminId: admin.id,
          decisionReason: reason,
          decidedAt,
        })
        .where(and(eq(withdrawals.id, withdrawalId), eq(withdrawals.status, 'PENDING')))
        .returning();

      if (updatedRows.length === 0) {
        return { kind: 'ALREADY_DECIDED' as const, wd: existing };
      }
      return { kind: 'CLAIMED' as const, wd: updatedRows[0] };
    });

    if (claimResult.kind === 'NOT_FOUND') {
      return NextResponse.json({ error: 'Withdrawal not found' }, { status: 404 });
    }
    if (claimResult.kind === 'ALREADY_DECIDED') {
      return NextResponse.json({
        ok: true,
        idempotentIgnored: true,
        status: claimResult.wd.status,
      });
    }

    const wd = claimResult.wd;

    try {
      await executeLedgerTransfer({
        userId: wd.userId,
        type: 'WITHDRAW_RELEASE',
        amountMinor: wd.amountMinor,
        idempotencyKey: `admin_reject_withdrawal_${wd.id}`,
        referenceId: `withdrawal:${wd.id}`,
        note: `Released held funds for rejected withdrawal #${wd.id}: ${reason}`,
      });
    } catch (ledgerErr) {
      await db
        .update(withdrawals)
        .set({
          status: 'PENDING',
          decidedByAdminId: null,
          decisionReason: null,
          decidedAt: null,
        })
        .where(eq(withdrawals.id, wd.id));
      throw ledgerErr;
    }

    await db.insert(notifications).values({
      userId: wd.userId,
      type: 'WITHDRAWAL_REJECTED',
      titleEn: `Withdrawal Rejected & Refunded to Balance`,
      titleAm: `የወጪ ጥያቄ ውድቅ ተደርጓል — ብሩ ወደ ቦርሳዎ ተመልሷል`,
      bodyEn: `Your withdrawal request was rejected (${reason}). The held ${formatEtb(wd.amountMinor, 'en')} has been released back to your available balance.`,
      bodyAm: `የወጪ ጥያቄዎ ውድቅ ተደርጓል (${reason})። ተይዞ የነበረው ${formatEtb(wd.amountMinor, 'am')} ወደ ቦርሳዎ ተመልሷል።`,
    });

    void recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: wd.userId,
      action: 'WITHDRAWAL_REJECTED_HOLD_RELEASED',
      reason,
      metadata: { withdrawalId: wd.id, amountMinor: wd.amountMinor },
      ipAddress: ip,
    }).catch(() => {});

    return NextResponse.json({
      ok: true,
      status: 'REJECTED',
      decidedAt: decidedAt.toISOString(),
      decisionReason: reason,
    });
  }

  // 6. KICK PLAYER (Disconnects session immediately, revokes tokens, invalidates password cache, tickets stay valid)
  if (action === 'kick_player') {
    const targetUserId = Number(body?.userId);
    const reason = String(body?.reason || 'Kicked by Administrator').trim();

    const targetRows = await db.select().from(users).where(eq(users.id, targetUserId));
    const target = targetRows[0];
    if (!target || target.role === 'admin') {
      return NextResponse.json({ error: 'Player not found' }, { status: 404 });
    }

    await db
      .update(users)
      .set({
        sessionVersion: target.sessionVersion + 1,
        activeSessionId: null,
      })
      .where(eq(users.id, target.id));

    invalidatePasswordVerificationCache(target.passwordHash);

    await db.insert(notifications).values({
      userId: target.id,
      type: 'ACCOUNT_STATUS',
      titleEn: 'Session Disconnected by Admin',
      titleAm: 'ክፍለ-ጊዜዎ በአድሚን ተቋርጧል',
      bodyEn: `You were signed out by the administrator (${reason}). You may sign in again.`,
      bodyAm: `በአድሚን ከሲስተሙ እንዲወጡ ተደርጓል (${reason})። በድጋሚ መግባት ይችላሉ።`,
    });

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: target.id,
      targetUsername: target.displayUsername,
      action: 'PLAYER_KICKED',
      reason,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true });
  }

  // 7. BLOCK PLAYER (Mandatory reason; status = BLOCKED; revokes sessions; invalidates password cache; refuses login & all API actions)
  if (action === 'block_player') {
    const targetUserId = Number(body?.userId);
    const reason = String(body?.reason || '').trim();
    if (reason.length < 3) {
      return NextResponse.json({ error: 'A mandatory block reason is required.' }, { status: 400 });
    }

    const targetRows = await db.select().from(users).where(eq(users.id, targetUserId));
    const target = targetRows[0];
    if (!target || target.role === 'admin') {
      return NextResponse.json({ error: 'Player not found' }, { status: 404 });
    }

    await db
      .update(users)
      .set({
        status: 'BLOCKED',
        blockedReason: reason,
        sessionVersion: target.sessionVersion + 1,
        activeSessionId: null,
      })
      .where(eq(users.id, target.id));

    // Immediately invalidate the banned/blocked user's entry in the HMAC password verification cache
    invalidatePasswordVerificationCache(target.passwordHash);

    await db.insert(notifications).values({
      userId: target.id,
      type: 'ACCOUNT_STATUS',
      titleEn: 'Account Blocked',
      titleAm: 'አካውንትዎ ታግዷል',
      bodyEn: `Your account has been blocked. Reason: ${reason}`,
      bodyAm: `አካውንትዎ ታግዷል። ምክንያት: ${reason}`,
    });

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: target.id,
      targetUsername: target.displayUsername,
      action: 'PLAYER_BLOCKED',
      reason,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true });
  }

  // 8. UNBLOCK PLAYER (Mandatory reason; restores status = ACTIVE)
  if (action === 'unblock_player') {
    const targetUserId = Number(body?.userId);
    const reason = String(body?.reason || '').trim();
    if (reason.length < 3) {
      return NextResponse.json({ error: 'A mandatory unblock reason is required.' }, { status: 400 });
    }

    const targetRows = await db.select().from(users).where(eq(users.id, targetUserId));
    const target = targetRows[0];
    if (!target || target.role === 'admin') {
      return NextResponse.json({ error: 'Player not found' }, { status: 404 });
    }

    await db
      .update(users)
      .set({
        status: 'ACTIVE',
        blockedReason: null,
        failedLoginAttempts: 0,
        lockedUntil: null,
      })
      .where(eq(users.id, target.id));

    invalidatePasswordVerificationCache(target.passwordHash);

    await db.insert(notifications).values({
      userId: target.id,
      type: 'ACCOUNT_STATUS',
      titleEn: 'Account Restored to Active',
      titleAm: 'አካውንትዎ ተከፍቷል',
      bodyEn: `Your account has been unblocked (${reason}). Welcome back!`,
      bodyAm: `አካውንትዎ እገዳው ተነስቷል (${reason})። እንኳን በደህና ተመለሱ!`,
    });

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: target.id,
      targetUsername: target.displayUsername,
      action: 'PLAYER_UNBLOCKED',
      reason,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true });
  }

  // 9. MANUAL WALLET ADJUSTMENT (Mandatory reason, logged in ledger + audit log)
  if (action === 'manual_adjustment') {
    const targetUserId = Number(body?.userId);
    const amountMinor = Number(body?.amountMinor);
    const direction = body?.direction === 'DEBIT' ? 'DEBIT' : 'CREDIT';
    const reason = String(body?.reason || '').trim();

    if (reason.length < 3) {
      return NextResponse.json({ error: 'Mandatory reason is required for manual adjustment' }, { status: 400 });
    }
    if (!Number.isInteger(amountMinor) || amountMinor <= 0) {
      return NextResponse.json({ error: 'Amount must be a positive integer in minor units' }, { status: 400 });
    }

    const targetRows = await db.select().from(users).where(eq(users.id, targetUserId));
    const target = targetRows[0];
    if (!target || target.role === 'admin') {
      return NextResponse.json({ error: 'Player not found' }, { status: 404 });
    }

    try {
      await executeLedgerTransfer({
        userId: target.id,
        type: 'MANUAL_ADJUSTMENT',
        amountMinor,
        adjustmentDirection: direction,
        idempotencyKey: `manual_adj_${admin.id}_${target.id}_${Date.now()}`,
        note: `Admin manual ${direction}: ${reason}`,
      });

      await recordAuditLog({
        actorUserId: admin.id,
        actorUsername: admin.displayUsername,
        targetUserId: target.id,
        targetUsername: target.displayUsername,
        action: `MANUAL_WALLET_${direction}`,
        reason,
        metadata: { amountMinor, direction },
        ipAddress: ip,
      });

      return NextResponse.json({ ok: true });
    } catch (error: any) {
      return NextResponse.json({ error: error?.message || 'Adjustment failed' }, { status: 400 });
    }
  }

  // 10. CREATE OR UPDATE ROOM (including Winning Pattern / ዝግ and Countdown Timer)
  if (action === 'save_room') {
    const roomId = body?.roomId ? Number(body.roomId) : null;
    const nameEn = String(body?.nameEn || '').trim();
    const nameAm = String(body?.nameAm || '').trim() || nameEn;
    const ticketPriceMinor = Number(body?.ticketPriceMinor);
    const pattern = VALID_PATTERNS.includes(body?.pattern)
      ? body.pattern
      : 'ONE_LINE';
    const minPlayers = Math.max(2, Number(body?.minPlayers || 2));
    const minCardsPerPlayer = Math.max(1, Number(body?.minCardsPerPlayer || 1));
    const maxCardsPerPlayer = Math.max(minCardsPerPlayer, Number(body?.maxCardsPerPlayer || 4));
    const houseFeeBps = Math.min(5000, Math.max(0, Number(body?.houseFeeBps ?? 2300)));
    const drawIntervalSeconds = Math.max(2, Number(body?.drawIntervalSeconds || 3));
    const cadenceSeconds = Math.min(300, Math.max(10, Number(body?.cadenceSeconds || 90)));
    const isPractice = Boolean(body?.isPractice);

    if (!nameEn || !Number.isInteger(ticketPriceMinor) || ticketPriceMinor < 0) {
      return NextResponse.json({ error: 'Valid room name and ticket price are required' }, { status: 400 });
    }

    if (!isPractice && body?.houseFeeBps !== undefined) {
      await setGlobalHouseCommissionBps(houseFeeBps);
    }

    if (roomId) {
      await db
        .update(rooms)
        .set({
          nameEn,
          nameAm,
          ticketPriceMinor,
          pattern,
          minPlayers,
          minCardsPerPlayer,
          maxCardsPerPlayer,
          houseFeeBps,
          drawIntervalSeconds,
          cadenceSeconds,
          isPractice,
        })
        .where(eq(rooms.id, roomId));

      // Also update any currently OPEN round in this room so players see the new pattern & bet amount immediately
      const openRounds = await db.select().from(rounds).where(eq(rounds.roomId, roomId));
      for (const r of openRounds) {
        if (r.status === 'OPEN') {
          const rTickets = await db.select().from(tickets).where(eq(tickets.roundId, r.id));
          const hasPriceMismatch =
            rTickets.length > 0 && rTickets.some((tk) => tk.pricePaidMinor !== ticketPriceMinor);
          if (hasPriceMismatch) {
            await cancelRoundAndRefundTickets(
              r.id,
              `የመወራረጃ ብር መጠን ወደ ${formatEtb(ticketPriceMinor, 'am')} በአድሚን ስለተቀየረ የነበረው ክፍያ ተመልሷል (Bet amount updated by Admin — tickets refunded)`,
              admin.displayUsername
            );
          } else {
            await db
              .update(rounds)
              .set({
                winningPattern: pattern,
                startsAt: new Date(Date.now() + cadenceSeconds * 1000),
              })
              .where(eq(rounds.id, r.id));
          }
        }
      }
    } else {
      const slug = `${nameEn.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString().slice(-4)}`;
      await db.insert(rooms).values({
        slug,
        nameEn,
        nameAm,
        ticketPriceMinor,
        pattern,
        minPlayers,
        minCardsPerPlayer,
        maxCardsPerPlayer,
        houseFeeBps,
        drawIntervalSeconds,
        cadenceSeconds,
        isPractice,
        isActive: true,
      });
    }

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      action: roomId ? 'ROOM_UPDATED' : 'ROOM_CREATED',
      reason: `${nameEn} (${formatEtb(ticketPriceMinor, 'en')}, ${pattern}, ${cadenceSeconds}s timer)`,
      metadata: { roomId, ticketPriceMinor, pattern, minPlayers, maxCardsPerPlayer, houseFeeBps, cadenceSeconds },
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true });
  }

  // 10b. QUICK BET AMOUNT ("የመወራረጃ ብር"), WINNING PATTERN ("ዝግ"), BALL DRAW SPEED & COUNTDOWN TIMER CONTROL
  if (action === 'set_winning_pattern' || action === 'set_bet_amount') {
    const targetRoomId = body?.roomId; // number or 'ALL'
    const pattern = VALID_PATTERNS.includes(body?.pattern) ? body.pattern : null;
    const countdownSeconds =
      body?.countdownSeconds !== undefined && body?.countdownSeconds !== null
        ? Math.min(300, Math.max(10, Number(body.countdownSeconds)))
        : null;
    const drawIntervalSeconds =
      body?.drawIntervalSeconds !== undefined && body?.drawIntervalSeconds !== null
        ? Math.min(5, Math.max(3, Number(body.drawIntervalSeconds)))
        : null;
    const ticketPriceMinor =
      body?.ticketPriceMinor !== undefined && body?.ticketPriceMinor !== null
        ? Math.max(100, Math.round(Number(body.ticketPriceMinor)))
        : null;

    if (
      !pattern &&
      countdownSeconds === null &&
      drawIntervalSeconds === null &&
      (ticketPriceMinor === null || Number.isNaN(ticketPriceMinor))
    ) {
      return NextResponse.json(
        { error: 'Specify ticketPriceMinor, pattern, countdownSeconds, or drawIntervalSeconds' },
        { status: 400 }
      );
    }

    const updateFields: Record<string, any> = {};
    if (pattern) updateFields.pattern = pattern;
    if (countdownSeconds !== null && !Number.isNaN(countdownSeconds)) {
      updateFields.cadenceSeconds = countdownSeconds;
    }
    if (drawIntervalSeconds !== null && !Number.isNaN(drawIntervalSeconds)) {
      updateFields.drawIntervalSeconds = drawIntervalSeconds;
    }
    if (ticketPriceMinor !== null && !Number.isNaN(ticketPriceMinor)) {
      updateFields.ticketPriceMinor = ticketPriceMinor;
    }

    const syncOpenRoundsForRoom = async (rId: number) => {
      const openRounds = await db.select().from(rounds).where(eq(rounds.roomId, rId));
      for (const r of openRounds) {
        if (r.status === 'OPEN') {
          if (ticketPriceMinor !== null && !Number.isNaN(ticketPriceMinor)) {
            const rTickets = await db.select().from(tickets).where(eq(tickets.roundId, r.id));
            const hasPriceMismatch =
              rTickets.length > 0 && rTickets.some((tk) => tk.pricePaidMinor !== ticketPriceMinor);
            if (hasPriceMismatch) {
              await cancelRoundAndRefundTickets(
                r.id,
                `የመወራረጃ ብር መጠን ወደ ${formatEtb(ticketPriceMinor, 'am')} በአድሚን ስለተቀየረ የነበረው ክፍያ ተመልሷል (Bet amount updated by Admin — tickets refunded)`,
                admin.displayUsername
              );
              continue;
            }
          }

          const roundUpdates: Record<string, any> = {};
          if (pattern) roundUpdates.winningPattern = pattern;
          if (countdownSeconds !== null && !Number.isNaN(countdownSeconds)) {
            roundUpdates.startsAt = new Date(Date.now() + countdownSeconds * 1000);
          }
          if (Object.keys(roundUpdates).length > 0) {
            await db.update(rounds).set(roundUpdates).where(eq(rounds.id, r.id));
          }
        }
      }
    };

    if (targetRoomId && targetRoomId !== 'ALL') {
      const rId = Number(targetRoomId);
      await db.update(rooms).set(updateFields).where(eq(rooms.id, rId));
      await syncOpenRoundsForRoom(rId);
    } else {
      const allRms = await db.select().from(rooms).where(eq(rooms.isActive, true));
      for (const rm of allRms) {
        await db.update(rooms).set(updateFields).where(eq(rooms.id, rm.id));
        await syncOpenRoundsForRoom(rm.id);
      }
    }

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      action: ticketPriceMinor !== null ? 'BET_AMOUNT_UPDATED' : 'WINNING_PATTERN_OR_TIMER_UPDATED',
      reason: `Room: ${targetRoomId || 'ALL'} | Bet: ${
        ticketPriceMinor !== null ? formatEtb(ticketPriceMinor, 'en') : 'unchanged'
      } | Pattern: ${pattern || 'unchanged'} | Timer: ${countdownSeconds ?? 'unchanged'}s | DrawSpeed: ${
        drawIntervalSeconds ?? 'unchanged'
      }s`,
      metadata: { targetRoomId, ticketPriceMinor, pattern, countdownSeconds, drawIntervalSeconds },
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true, ticketPriceMinor });
  }

  // 10b-1. ADMIN GAME SCHEDULING & BETTING CONTROL (Toggle Betting Window & Set Next Game Start Time)
  if (action === 'toggle_betting_window') {
    const currentSchedule = await getGameBettingSchedule();
    const isBettingOpen =
      body?.isBettingOpen !== undefined ? Boolean(body.isBettingOpen) : !currentSchedule.isBettingOpen;
    const updated = await setGameBettingSchedule(
      { isBettingOpen },
      admin.displayUsername
    );

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      action: isBettingOpen ? 'BETTING_WINDOW_OPENED' : 'BETTING_WINDOW_CLOSED',
      reason: isBettingOpen
        ? 'Admin manually OPENED the betting window for all players'
        : 'Admin manually CLOSED the betting window for all players',
      metadata: { isBettingOpen, scheduledGameTime: updated.scheduledGameTime },
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      message: isBettingOpen
        ? 'ውርርድ ክፍት ተደርጓል! ተጫዋቾች ካርቴላ መግዛት ይችላሉ። (Betting window opened)'
        : 'ውርርድ ተዘግቷል! ተጫዋቾች አዲስ ካርቴላ መግዛት አይችሉም። (Betting window closed)',
      bettingSchedule: updated,
    });
  }

  if (action === 'update_game_modes') {
    const isPracticeModeOpen =
      body?.isPracticeModeOpen !== undefined ? Boolean(body.isPracticeModeOpen) : undefined;
    const practiceOffReason =
      body?.practiceOffReason !== undefined ? String(body.practiceOffReason).trim() : undefined;
    const practiceResumeTime =
      body?.practiceResumeTime !== undefined ? String(body.practiceResumeTime).trim() : undefined;

    const isRealGameModeOpen =
      body?.isRealGameModeOpen !== undefined ? Boolean(body.isRealGameModeOpen) : undefined;
    const realGameOffReason =
      body?.realGameOffReason !== undefined ? String(body.realGameOffReason).trim() : undefined;
    const realGameResumeTime =
      body?.realGameResumeTime !== undefined ? String(body.realGameResumeTime).trim() : undefined;

    const customNoticeAm =
      body?.customNoticeAm !== undefined ? String(body.customNoticeAm).trim() : undefined;
    const customNoticeEn =
      body?.customNoticeEn !== undefined ? String(body.customNoticeEn).trim() : undefined;

    const updated = await setGameBettingSchedule(
      {
        ...(isPracticeModeOpen !== undefined ? { isPracticeModeOpen } : {}),
        ...(practiceOffReason !== undefined ? { practiceOffReason } : {}),
        ...(practiceResumeTime !== undefined ? { practiceResumeTime } : {}),
        ...(isRealGameModeOpen !== undefined
          ? { isRealGameModeOpen, isBettingOpen: isRealGameModeOpen }
          : {}),
        ...(realGameOffReason !== undefined ? { realGameOffReason } : {}),
        ...(realGameResumeTime !== undefined ? { realGameResumeTime } : {}),
        ...(customNoticeAm !== undefined ? { customNoticeAm } : {}),
        ...(customNoticeEn !== undefined ? { customNoticeEn } : {}),
      },
      admin.displayUsername
    );

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      action: 'GAME_MODES_UPDATED',
      reason: `Practice Mode: ${updated.isPracticeModeOpen ? 'ON' : 'OFF'} | Real Game Mode: ${updated.isRealGameModeOpen ? 'ON' : 'OFF'}`,
      metadata: {
        isPracticeModeOpen: updated.isPracticeModeOpen,
        practiceOffReason: updated.practiceOffReason,
        practiceResumeTime: updated.practiceResumeTime,
        isRealGameModeOpen: updated.isRealGameModeOpen,
        realGameOffReason: updated.realGameOffReason,
        realGameResumeTime: updated.realGameResumeTime,
      },
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      message: 'የጨዋታ ሁኔታዎች እና ማሳወቂያ በተሳካ ሁኔታ ተቀይረዋል! (Game mode settings updated)',
      bettingSchedule: updated,
    });
  }

  if (action === 'set_game_schedule') {
    const rawTime = body?.scheduledGameTime;
    let scheduledGameTime: string | null | undefined = undefined;
    if (rawTime === null) {
      scheduledGameTime = null;
    } else if (rawTime) {
      const parsed = new Date(rawTime);
      if (!Number.isNaN(parsed.getTime())) {
        scheduledGameTime = parsed.toISOString();
      }
    }
    const isBettingOpen =
      body?.isBettingOpen !== undefined ? Boolean(body.isBettingOpen) : undefined;
    const isPracticeModeOpen =
      body?.isPracticeModeOpen !== undefined ? Boolean(body.isPracticeModeOpen) : undefined;
    const practiceOffReason =
      body?.practiceOffReason !== undefined ? String(body.practiceOffReason).trim() : undefined;
    const practiceResumeTime =
      body?.practiceResumeTime !== undefined ? String(body.practiceResumeTime).trim() : undefined;
    const isRealGameModeOpen =
      body?.isRealGameModeOpen !== undefined ? Boolean(body.isRealGameModeOpen) : undefined;
    const realGameOffReason =
      body?.realGameOffReason !== undefined ? String(body.realGameOffReason).trim() : undefined;
    const realGameResumeTime =
      body?.realGameResumeTime !== undefined ? String(body.realGameResumeTime).trim() : undefined;
    const customNoticeEn =
      body?.customNoticeEn !== undefined ? String(body.customNoticeEn).trim() : undefined;
    const customNoticeAm =
      body?.customNoticeAm !== undefined ? String(body.customNoticeAm).trim() : undefined;

    const updated = await setGameBettingSchedule(
      {
        ...(scheduledGameTime !== undefined ? { scheduledGameTime } : {}),
        ...(isBettingOpen !== undefined ? { isBettingOpen } : {}),
        ...(isPracticeModeOpen !== undefined ? { isPracticeModeOpen } : {}),
        ...(practiceOffReason !== undefined ? { practiceOffReason } : {}),
        ...(practiceResumeTime !== undefined ? { practiceResumeTime } : {}),
        ...(isRealGameModeOpen !== undefined ? { isRealGameModeOpen } : {}),
        ...(realGameOffReason !== undefined ? { realGameOffReason } : {}),
        ...(realGameResumeTime !== undefined ? { realGameResumeTime } : {}),
        ...(customNoticeEn !== undefined ? { customNoticeEn } : {}),
        ...(customNoticeAm !== undefined ? { customNoticeAm } : {}),
      },
      admin.displayUsername
    );

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      action: 'GAME_SCHEDULE_UPDATED',
      reason: scheduledGameTime
        ? `Admin scheduled next live game for ${scheduledGameTime} (Betting Open: ${updated.isBettingOpen})`
        : 'Admin updated game schedule / status announcement',
      metadata: { scheduledGameTime: updated.scheduledGameTime, isBettingOpen: updated.isBettingOpen },
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      message: scheduledGameTime
        ? `ቀጣዩ የቀጥታ ጨዋታ ለ ${new Date(scheduledGameTime).toLocaleString()} ተመድቧል! (Game scheduled successfully)`
        : 'የጨዋታ መርሃ-ግብር እና ማሳወቂያ ተቀምጧል! (Game schedule updated)',
      bettingSchedule: updated,
    });
  }

  // 10b-2. DYNAMIC HOUSE COMMISSION PERCENTAGE SETTINGS
  if (action === 'set_house_commission') {
    const targetRoomId = body?.roomId; // number or 'ALL'
    let houseFeeBps: number | null = null;

    if (body?.commissionPercent !== undefined && body?.commissionPercent !== null) {
      const pct = Number(body.commissionPercent);
      if (Number.isNaN(pct) || pct < 0 || pct > 50) {
        return NextResponse.json(
          { error: 'እባክዎ ትክክለኛ የኮሚሽን መቶኛ ከ 0% እስከ 50% ያስገቡ (Commission percentage must be between 0% and 50%).' },
          { status: 400 }
        );
      }
      houseFeeBps = Math.round(pct * 100);
    } else if (body?.houseFeeBps !== undefined && body?.houseFeeBps !== null) {
      const bps = Number(body.houseFeeBps);
      if (Number.isNaN(bps) || bps < 0 || bps > 5000) {
        return NextResponse.json(
          { error: 'House commission basis points must be between 0 and 5000 (0% to 50%).' },
          { status: 400 }
        );
      }
      houseFeeBps = Math.round(bps);
    }

    if (houseFeeBps === null) {
      return NextResponse.json(
        { error: 'Specify commissionPercent (0-50) or houseFeeBps (0-5000)' },
        { status: 400 }
      );
    }

    // Persist global house commission setting
    await setGlobalHouseCommissionBps(houseFeeBps);
    const appliedPercent = Number((houseFeeBps / 100).toFixed(2));

    const recalculateActiveRoundsForRoom = async (rId: number, roomTicketPriceMinor: number) => {
      const rmRounds = await db.select().from(rounds).where(eq(rounds.roomId, rId));
      for (const r of rmRounds) {
        if (r.status === 'OPEN' || r.status === 'DRAWING') {
          const rTickets = await db.select().from(tickets).where(eq(tickets.roundId, r.id));
          const unitPrice =
            rTickets.length > 0 ? rTickets[0].pricePaidMinor : roomTicketPriceMinor;
          const math = calculateRoundPayouts({
            ticketCount: rTickets.length,
            ticketPriceMinor: unitPrice,
            houseFeeBps,
            winnerIds: [],
          });
          await db
            .update(rounds)
            .set({
              potMinor: math.potMinor,
              houseFeeMinor: math.baseHouseFeeMinor,
              prizeMinor: math.netPrizeMinor,
            })
            .where(eq(rounds.id, r.id));
        }
      }
    };

    if (targetRoomId && targetRoomId !== 'ALL') {
      const rId = Number(targetRoomId);
      const rmRows = await db.select().from(rooms).where(eq(rooms.id, rId));
      const rm = rmRows[0];
      if (!rm) {
        return NextResponse.json({ error: 'Room not found' }, { status: 404 });
      }
      await db.update(rooms).set({ houseFeeBps }).where(eq(rooms.id, rId));
      await recalculateActiveRoundsForRoom(rId, rm.ticketPriceMinor);
    }

    // Always apply the admin's house commission to all active real-money rooms so it never drifts
    const allRms = await db.select().from(rooms).where(eq(rooms.isActive, true));
    for (const rm of allRms) {
      if (!rm.isPractice) {
        await db.update(rooms).set({ houseFeeBps }).where(eq(rooms.id, rm.id));
        await recalculateActiveRoundsForRoom(rm.id, rm.ticketPriceMinor);
      }
    }

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      action: 'HOUSE_COMMISSION_UPDATED',
      reason: `Updated House Commission to ${appliedPercent}% (${houseFeeBps} bps) for Room: ${targetRoomId || 'ALL'}`,
      metadata: {
        targetRoomId: targetRoomId || 'ALL',
        houseFeeBps,
        commissionPercent: appliedPercent,
      },
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      houseFeeBps,
      commissionPercent: appliedPercent,
    });
  }

  // 10c. PREDETERMINED WINNER SELECTION (Target Specific Card ID #1-#120 or Player to Win)
  if (action === 'set_predetermined_winner') {
    const rawRoomId = body?.roomId;
    const roomId: number | 'ALL' =
      rawRoomId && rawRoomId !== 'ALL' ? Number(rawRoomId) : 'ALL';
    const enabled = Boolean(body?.enabled);
    const targetType: 'CARD' | 'PLAYER' = body?.targetType === 'PLAYER' ? 'PLAYER' : 'CARD';
    const targetCardIndex =
      body?.targetCardIndex !== undefined && body?.targetCardIndex !== null
        ? Math.min(400, Math.max(1, Math.round(Number(body.targetCardIndex))))
        : null;
    const targetUserId =
      body?.targetUserId !== undefined && body?.targetUserId !== null
        ? Number(body.targetUserId)
        : null;
    const autoClearAfterWin =
      body?.autoClearAfterWin !== undefined ? Boolean(body.autoClearAfterWin) : true;

    let targetUsername: string | null = null;
    if (enabled && targetType === 'PLAYER' && targetUserId) {
      const foundUsers = await db.select().from(users).where(eq(users.id, targetUserId));
      if (!foundUsers[0]) {
        return NextResponse.json({ error: 'Selected player not found' }, { status: 404 });
      }
      targetUsername = foundUsers[0].displayUsername;
    }

    if (enabled && targetType === 'CARD' && (!targetCardIndex || Number.isNaN(targetCardIndex))) {
      return NextResponse.json(
        { error: 'እባክዎ ትክክለኛ የካርቴላ ቁጥር (#1 - #120) ያስገቡ (Valid Card ID is required)' },
        { status: 400 }
      );
    }

    if (enabled && targetType === 'PLAYER' && (!targetUserId || Number.isNaN(targetUserId))) {
      return NextResponse.json(
        { error: 'እባክዎ ተጫዋች ይምረጡ (Valid Player selection is required)' },
        { status: 400 }
      );
    }

    const targetConfig: PredeterminedWinnerTarget = {
      enabled,
      roomId,
      targetType,
      targetCardIndex: targetType === 'CARD' ? targetCardIndex : null,
      targetUserId: targetType === 'PLAYER' ? targetUserId : null,
      targetUsername,
      autoClearAfterWin,
      appliedRoundIds: [],
      updatedAt: new Date().toISOString(),
      updatedBy: admin.displayUsername,
    };

    const allTargets = await savePredeterminedWinnerTarget(targetConfig);

    // Immediately apply (or restore fair random sequence) on any active OPEN or DRAWING rounds
    const affectedRooms =
      roomId === 'ALL'
        ? await db.select().from(rooms).where(eq(rooms.isActive, true))
        : await db.select().from(rooms).where(eq(rooms.id, roomId));

    for (const rm of affectedRooms) {
      const rmRounds = await db
        .select()
        .from(rounds)
        .where(eq(rounds.roomId, rm.id));
      for (const rd of rmRounds) {
        if (rd.status === 'OPEN' || rd.status === 'DRAWING') {
          if (!enabled) {
            if (rd.status === 'OPEN') {
              const fairSeq = deriveDrawOrder(rd.serverSeed, rd.id);
              await db
                .update(rounds)
                .set({ drawSequenceJson: JSON.stringify(fairSeq) })
                .where(eq(rounds.id, rd.id));
            }
          } else {
            const rdTickets = await db
              .select()
              .from(tickets)
              .where(eq(tickets.roundId, rd.id))
              .orderBy(asc(tickets.id));
            const existingDraws =
              rd.status === 'DRAWING'
                ? await db
                    .select()
                    .from(roundDraws)
                    .where(eq(roundDraws.roundId, rd.id))
                    .orderBy(asc(roundDraws.drawOrder))
                : [];
            const alreadyCalled = existingDraws.map((d) => d.ballNumber);
            const computed = computeTargetedSequenceForRound({
              target: targetConfig,
              roundTickets: rdTickets,
              pattern: rd.winningPattern || rm.pattern,
              alreadyDrawn: alreadyCalled,
            });
            if (computed.matched && computed.sequence && computed.sequence.length === 75) {
              await db
                .update(rounds)
                .set({ drawSequenceJson: JSON.stringify(computed.sequence) })
                .where(eq(rounds.id, rd.id));
            }
          }
        }
      }
    }

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: targetUserId || undefined,
      targetUsername: targetUsername || undefined,
      action: enabled ? 'PREDETERMINED_WINNER_SET' : 'PREDETERMINED_WINNER_CLEARED',
      reason: enabled
        ? targetType === 'CARD'
          ? `Target Card #${targetCardIndex} (Room: ${roomId})`
          : `Target Player ${targetUsername} (#${targetUserId}, Room: ${roomId})`
        : `Cleared predetermined winner (Room: ${roomId})`,
      metadata: {
        roomId,
        enabled,
        targetType,
        targetCardIndex,
        targetUserId,
        targetUsername,
        autoClearAfterWin,
      },
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      predeterminedTargets: allTargets,
    });
  }

  // 10d. FORCE START ACTIVE OPEN ROUND IMMEDIATELY
  if (action === 'force_start_round') {
    const rawRoomId = body?.roomId;
    const affectedRooms =
      rawRoomId && rawRoomId !== 'ALL'
        ? await db.select().from(rooms).where(eq(rooms.id, Number(rawRoomId)))
        : await db.select().from(rooms).where(eq(rooms.isActive, true));

    let startedCount = 0;
    for (const rm of affectedRooms) {
      const openRds = await db
        .select()
        .from(rounds)
        .where(eq(rounds.roomId, rm.id));
      for (const rd of openRds) {
        if (rd.status === 'OPEN') {
          const rdTickets = await db.select().from(tickets).where(eq(tickets.roundId, rd.id));
          if (rdTickets.length > 0) {
            await db
              .update(rounds)
              .set({ startsAt: new Date(Date.now() - 500) })
              .where(eq(rounds.id, rd.id));
            await syncRoomState(rm.id);
            startedCount += 1;
          }
        }
      }
    }

    if (startedCount === 0) {
      return NextResponse.json(
        {
          error:
            'በአሁኑ ዙር የተገዛ ካርቴላ የለም። ዙሩን ወዲያውኑ ለማስጀመር ቢያንስ 1 ካርቴላ መገዛት አለበት (At least 1 purchased ticket is required to force-start a round).',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({ ok: true, startedCount });
  }

  // 11. CANCEL ACTIVE ROUND IN ROOM WITH FULL REFUNDS
  if (action === 'cancel_round') {
    const roomId = Number(body?.roomId);
    const reason = String(body?.reason || 'Admin cancelled round & refunded all tickets').trim();

    const activeRounds = await db.select().from(rounds).where(eq(rounds.roomId, roomId));
    for (const r of activeRounds) {
      if (r.status === 'OPEN' || r.status === 'LOCKED' || r.status === 'DRAWING') {
        await cancelRoundAndRefundTickets(r.id, reason, admin.displayUsername);
      }
    }
    return NextResponse.json({ ok: true });
  }

  // 12. TOGGLE MAINTENANCE MODE
  if (action === 'toggle_maintenance') {
    const enabled = Boolean(body?.enabled);
    await db
      .insert(systemSettings)
      .values({
        key: 'maintenance_mode',
        value: enabled ? 'true' : 'false',
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: systemSettings.key,
        set: {
          value: enabled ? 'true' : 'false',
          updatedAt: new Date(),
        },
      });

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      action: enabled ? 'MAINTENANCE_MODE_ENABLED' : 'MAINTENANCE_MODE_DISABLED',
      reason: enabled
        ? 'Stopped new rounds while letting running rounds finish'
        : 'Resumed normal round scheduling',
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true, maintenanceMode: enabled });
  }

  // 13. ADMIN RESET PLAYER PASSWORD
  if (action === 'admin_reset_player_password') {
    const rawUserId = body?.userId ? Number(body.userId) : null;
    const rawRequestId = body?.requestId ? Number(body.requestId) : null;
    const newPassword = String(body?.newPassword || '').trim();

    if (newPassword.length < 4) {
      return NextResponse.json(
        { error: 'አዲሱ የይለፍ ቃል ቢያንስ 4 ፊደላት/ቁጥሮች መሆን አለበት (Password must be at least 4 characters)' },
        { status: 400 }
      );
    }

    let targetUser: typeof users.$inferSelect | null = null;
    let resetReq: typeof passwordResets.$inferSelect | null = null;

    if (rawRequestId) {
      const foundReq = await db.select().from(passwordResets).where(eq(passwordResets.id, rawRequestId));
      resetReq = foundReq[0] || null;
      if (resetReq?.userId) {
        const foundUser = await db.select().from(users).where(eq(users.id, resetReq.userId));
        targetUser = foundUser[0] || null;
      } else if (resetReq?.username) {
        const lookup = resetReq.username.trim().toLowerCase();
        const foundUser = await db
          .select()
          .from(users)
          .where(
            or(
              eq(users.username, lookup),
              sql`LOWER(TRIM(${users.displayUsername})) = ${lookup}`,
              sql`LOWER(TRIM(${users.email})) = ${lookup}`
            )
          );
        targetUser = foundUser[0] || null;
      }
    }

    if (!targetUser && rawUserId) {
      const foundUser = await db.select().from(users).where(eq(users.id, rawUserId));
      targetUser = foundUser[0] || null;
    }

    if (!targetUser) {
      return NextResponse.json({ error: 'ተጫዋቹ አልተገኘም (Player not found)' }, { status: 404 });
    }

    if (targetUser.role === 'admin') {
      return NextResponse.json({ error: 'Cannot reset admin credentials via this action' }, { status: 403 });
    }

    const oldPasswordHash = targetUser.passwordHash;
    const newPasswordHash = hashPassword(newPassword, true);

    // Update player password hash, clear failed attempts and locks, increment sessionVersion to revoke existing tokens
    await db
      .update(users)
      .set({
        passwordHash: newPasswordHash,
        failedLoginAttempts: 0,
        lockedUntil: null,
        sessionVersion: targetUser.sessionVersion + 1,
        activeSessionId: null,
      })
      .where(eq(users.id, targetUser.id));

    // Immediately invalidate the old password hash from the HMAC verification cache
    invalidatePasswordVerificationCache(oldPasswordHash);

    if (resetReq) {
      await db
        .update(passwordResets)
        .set({
          userId: targetUser.id,
          status: 'RESOLVED',
          tempPasswordPlain: newPassword,
          decidedByAdminId: admin.id,
          decidedAt: new Date(),
        })
        .where(eq(passwordResets.id, resetReq.id));
    }

    await db.insert(notifications).values({
      userId: targetUser.id,
      type: 'ACCOUNT_STATUS',
      titleEn: 'Password Reset by Admin',
      titleAm: 'የይለፍ ቃልዎ በአድሚን ተቀይሯል',
      bodyEn: `Your password has been reset by the administrator. Use your new password to sign in.`,
      bodyAm: `የይለፍ ቃልዎ በአድሚኑ ተቀይሯል። በአዲሱ የይለፍ ቃልዎ መግባት ይችላሉ።`,
    });

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: targetUser.id,
      targetUsername: targetUser.displayUsername,
      action: 'ADMIN_RESET_PLAYER_PASSWORD',
      reason: resetReq ? `Resolved reset request #${resetReq.id}` : 'Direct admin reset from players dashboard',
      metadata: {
        requestId: resetReq?.id || null,
        playerUsername: targetUser.displayUsername,
      },
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      username: targetUser.displayUsername,
      tempPassword: newPassword,
      message: `የተጫዋች ${targetUser.displayUsername} የይለፍ ቃል በተሳካ ሁኔታ ተቀይሯል!`,
    });
  }

  // 14. REJECT PASSWORD RESET REQUEST
  if (action === 'reject_password_reset') {
    const rawRequestId = Number(body?.requestId);
    const reason = String(body?.reason || 'Rejected by Admin').trim();

    if (!rawRequestId) {
      return NextResponse.json({ error: 'Request ID is required' }, { status: 400 });
    }

    const foundReq = await db.select().from(passwordResets).where(eq(passwordResets.id, rawRequestId));
    const resetReq = foundReq[0];
    if (!resetReq) {
      return NextResponse.json({ error: 'Reset request not found' }, { status: 404 });
    }

    await db
      .update(passwordResets)
      .set({
        status: 'REJECTED',
        rejectionReason: reason,
        decidedByAdminId: admin.id,
        decidedAt: new Date(),
      })
      .where(eq(passwordResets.id, resetReq.id));

    await recordAuditLog({
      actorUserId: admin.id,
      actorUsername: admin.displayUsername,
      targetUserId: resetReq.userId || undefined,
      targetUsername: resetReq.username,
      action: 'ADMIN_REJECTED_PASSWORD_RESET',
      reason,
      metadata: { requestId: resetReq.id },
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      message: `የይለፍ ቃል ጥያቄ #${resetReq.id} ውድቅ ተደርጓል።`,
    });
  }

  // 15. ADMIN SEARCH PLAYER GAME HISTORY BY USERNAME (Complete Win/Loss History, Financials, Provably Fair Seeds, Practice vs Live Isolation, Date Filtering & Pagination)
  if (action === 'search_player_history') {
    const queryUsername = String(body?.username || '').trim();
    const modeFilter =
      String(body?.mode || 'LIVE').toUpperCase() === 'PRACTICE' ? 'PRACTICE' : 'LIVE';
    const dateFromParam = body?.dateFrom ? String(body.dateFrom).trim() : null;
    const dateToParam = body?.dateTo ? String(body.dateTo).trim() : null;
    const page = Math.max(1, parseInt(String(body?.page || '1'), 10) || 1);
    const pageSize = Math.min(50, Math.max(5, parseInt(String(body?.pageSize || '10'), 10) || 10));

    if (!queryUsername) {
      return NextResponse.json(
        {
          error: 'እባክዎ የተጫዋች ስም (Username) ያስገቡ (Please enter a username to search)',
          code: 'EMPTY_USERNAME',
        },
        { status: 400 }
      );
    }

    const allPlayerCandidates = await db
      .select()
      .from(users)
      .where(eq(users.role, 'player'));

    const lowerQuery = queryUsername.toLowerCase();
    const exactMatch = allPlayerCandidates.find(
      (u) =>
        u.username.toLowerCase() === lowerQuery ||
        u.displayUsername.toLowerCase() === lowerQuery
    );
    const partialMatch =
      exactMatch ||
      allPlayerCandidates.find(
        (u) =>
          u.username.toLowerCase().includes(lowerQuery) ||
          u.displayUsername.toLowerCase().includes(lowerQuery)
      );

    if (!partialMatch) {
      return NextResponse.json(
        {
          error: `User not found: "${queryUsername}" — ተጫዋቹ አልተገኘም! እባክዎ ትክክለኛ የተጫዋች ስም (Username) ያስገቡ።`,
          code: 'USER_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    const targetPlayer = partialMatch;
    const playerWalletRows = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, targetPlayer.id));
    const playerWallet = playerWalletRows[0];

    const allRoomsList = await db.select().from(rooms);
    const roomMap = new Map(allRoomsList.map((r) => [r.id, r]));

    const playerTicketsRaw = await db
      .select()
      .from(tickets)
      .where(eq(tickets.userId, targetPlayer.id))
      .orderBy(desc(tickets.id));

    const playerRoundIds = Array.from(new Set(playerTicketsRaw.map((t) => t.roundId)));
    const relatedRounds =
      playerRoundIds.length > 0
        ? await db.select().from(rounds).where(inArray(rounds.id, playerRoundIds))
        : [];
    const roundMap = new Map(relatedRounds.map((r) => [r.id, r]));

    const allTicketsInPlayerRounds =
      playerRoundIds.length > 0
        ? await db.select().from(tickets).where(inArray(tickets.roundId, playerRoundIds))
        : [];

    const allUsersMap = new Map(
      allPlayerCandidates.map((u) => [u.id, u.displayUsername || u.username])
    );

    const ticketsByRound = new Map<number, typeof allTicketsInPlayerRounds>();
    for (const tk of allTicketsInPlayerRounds) {
      const list = ticketsByRound.get(tk.roundId) || [];
      list.push(tk);
      ticketsByRound.set(tk.roundId, list);
    }

    const dateFromMs = dateFromParam ? new Date(`${dateFromParam}T00:00:00.000Z`).getTime() : null;
    const dateToMs = dateToParam ? new Date(`${dateToParam}T23:59:59.999Z`).getTime() : null;

    const withinDateRange = (isoOrDate: Date | string | null | undefined): boolean => {
      if (!dateFromMs && !dateToMs) return true;
      const ts = isoOrDate ? new Date(isoOrDate).getTime() : Date.now();
      if (Number.isNaN(ts)) return true;
      if (dateFromMs && !Number.isNaN(dateFromMs) && ts < dateFromMs) return false;
      if (dateToMs && !Number.isNaN(dateToMs) && ts > dateToMs) return false;
      return true;
    };

    const formattedTickets = playerTicketsRaw.map((t) => {
      const r = roundMap.get(t.roundId);
      const rm = roomMap.get(t.roomId);
      const isPractice = Boolean(rm?.isPractice);
      const isWon = t.payoutMinor > 0 || t.claimValid === true;
      const roundStatus = r?.status || 'OPEN';
      const isLost = roundStatus === 'SETTLED' && !isWon;
      const rTickets = ticketsByRound.get(t.roundId) || [];
      const winningCards = rTickets
        .filter((rt) => rt.payoutMinor > 0 || rt.claimValid === true)
        .map((rt) => ({
          cardIndex: rt.cardIndex,
          username: allUsersMap.get(rt.userId) || `Player #${rt.userId}`,
          payoutMinor: rt.payoutMinor,
        }));

      return {
        ticketId: t.id,
        roundId: t.roundId,
        roomId: t.roomId,
        roomNameEn: rm?.nameEn || 'Bingo Room',
        roomNameAm: rm?.nameAm || 'የቢንጎ ክፍል',
        isPractice,
        modeTag: isPractice ? 'PRACTICE_DEMO' : 'REAL_LIVE',
        cardIndex: t.cardIndex,
        pricePaidMinor: t.pricePaidMinor,
        payoutMinor: t.payoutMinor,
        wonAmountMinor: isWon ? t.payoutMinor : 0,
        lostAmountMinor: isLost ? t.pricePaidMinor : 0,
        roundStatus,
        winningPattern: r?.winningPattern || rm?.pattern || 'ONE_LINE',
        drawnCount: r?.drawnCount || 0,
        potMinor: r?.potMinor || 0,
        prizeMinor: r?.prizeMinor || 0,
        serverSeedHash: r?.serverSeedHash || '',
        serverSeed: r?.serverSeed || null,
        won: isWon,
        lost: isLost,
        winningCards,
        settledAt: r?.settledAt ? r.settledAt.toISOString() : null,
        createdAt: t.createdAt.toISOString(),
      };
    });

    const liveTicketsFiltered = formattedTickets.filter(
      (tk) => !tk.isPractice && withinDateRange(tk.settledAt || tk.createdAt)
    );
    const practiceTicketsFiltered = formattedTickets.filter(
      (tk) => tk.isPractice && withinDateRange(tk.settledAt || tk.createdAt)
    );

    const groupByRound = (list: typeof formattedTickets) => {
      const map = new Map<
        number,
        {
          roundId: number;
          roomId: number;
          roomNameEn: string;
          roomNameAm: string;
          isPractice: boolean;
          modeTag: string;
          roundStatus: string;
          winningPattern: string;
          drawnCount: number;
          ballsDrawnCount: number;
          potMinor: number;
          prizeMinor: number;
          serverSeedHash: string;
          serverSeed: string | null;
          wonAmountMinor: number;
          lostAmountMinor: number;
          totalStakedMinor: number;
          wonCards: Array<{ cardIndex: number; payoutMinor: number }>;
          lostCards: Array<{ cardIndex: number; pricePaidMinor: number }>;
          activeCards: Array<{ cardIndex: number; pricePaidMinor: number }>;
          winningCards: Array<{ cardIndex: number; username: string; payoutMinor: number }>;
          roundWinningCards: Array<{ cardIndex: number; username: string; payoutMinor: number }>;
          settledAt: string | null;
          createdAt: string;
          timestampUtc: string;
        }
      >();

      for (const g of list) {
        const ex = map.get(g.roundId);
        if (!ex) {
          map.set(g.roundId, {
            roundId: g.roundId,
            roomId: g.roomId,
            roomNameEn: g.roomNameEn,
            roomNameAm: g.roomNameAm,
            isPractice: g.isPractice,
            modeTag: g.modeTag,
            roundStatus: g.roundStatus,
            winningPattern: g.winningPattern,
            drawnCount: g.drawnCount,
            ballsDrawnCount: g.drawnCount,
            potMinor: g.potMinor,
            prizeMinor: g.prizeMinor,
            serverSeedHash: g.serverSeedHash,
            serverSeed: g.serverSeed,
            wonAmountMinor: g.wonAmountMinor,
            lostAmountMinor: g.lostAmountMinor,
            totalStakedMinor: g.pricePaidMinor,
            wonCards: g.won ? [{ cardIndex: g.cardIndex, payoutMinor: g.payoutMinor }] : [],
            lostCards: g.lost ? [{ cardIndex: g.cardIndex, pricePaidMinor: g.pricePaidMinor }] : [],
            activeCards:
              !g.won && !g.lost
                ? [{ cardIndex: g.cardIndex, pricePaidMinor: g.pricePaidMinor }]
                : [],
            winningCards: g.winningCards,
            roundWinningCards: g.winningCards,
            settledAt: g.settledAt,
            createdAt: g.createdAt,
            timestampUtc: g.settledAt || g.createdAt,
          });
        } else {
          ex.wonAmountMinor += g.wonAmountMinor;
          ex.lostAmountMinor += g.lostAmountMinor;
          ex.totalStakedMinor += g.pricePaidMinor;
          if (g.won) {
            ex.wonCards.push({ cardIndex: g.cardIndex, payoutMinor: g.payoutMinor });
          } else if (g.lost) {
            ex.lostCards.push({ cardIndex: g.cardIndex, pricePaidMinor: g.pricePaidMinor });
          } else {
            ex.activeCards.push({ cardIndex: g.cardIndex, pricePaidMinor: g.pricePaidMinor });
          }
        }
      }
      return Array.from(map.values()).sort((a, b) => b.roundId - a.roundId);
    };

    const liveRoundsAll = groupByRound(liveTicketsFiltered);
    const practiceRoundsAll = groupByRound(practiceTicketsFiltered);

    const buildSummary = (
      roundsArr: typeof liveRoundsAll,
      ticketsArr: typeof liveTicketsFiltered
    ) => {
      const totalWonMinor = ticketsArr.reduce((acc, t) => acc + t.wonAmountMinor, 0);
      const totalLostMinor = ticketsArr.reduce((acc, t) => acc + t.lostAmountMinor, 0);
      const totalStakedMinor = ticketsArr.reduce((acc, t) => acc + t.pricePaidMinor, 0);
      return {
        totalRounds: roundsArr.length,
        totalTickets: ticketsArr.length,
        wonTicketsCount: ticketsArr.filter((t) => t.won).length,
        lostTicketsCount: ticketsArr.filter((t) => t.lost).length,
        totalStakedMinor,
        totalWonMinor,
        totalLostMinor,
        netProfitLossMinor: totalWonMinor - totalLostMinor,
      };
    };

    const selectedRoundsAll = modeFilter === 'PRACTICE' ? practiceRoundsAll : liveRoundsAll;
    const totalItems = selectedRoundsAll.length;
    const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
    const safePage = Math.min(page, totalPages);
    const paginatedRounds = selectedRoundsAll.slice(
      (safePage - 1) * pageSize,
      safePage * pageSize
    );

    const nowIso = new Date().toISOString();

    return NextResponse.json({
      ok: true,
      asOfTimestamp: nowIso,
      mode: modeFilter,
      player: {
        id: targetPlayer.id,
        username: targetPlayer.displayUsername,
        email: targetPlayer.email,
        phone: targetPlayer.phone,
        status: targetPlayer.status,
        blockedReason: targetPlayer.blockedReason,
        balanceMinor: playerWallet?.balanceMinor || 0,
        lockedMinor: playerWallet?.lockedMinor || 0,
        playBalanceMinor: playerWallet?.playBalanceMinor || 0,
        createdAt: targetPlayer.createdAt.toISOString(),
        lastActiveAt: targetPlayer.lastActiveAt.toISOString(),
      },
      liveSummary: buildSummary(liveRoundsAll, liveTicketsFiltered),
      practiceSummary: buildSummary(practiceRoundsAll, practiceTicketsFiltered),
      pagination: {
        page: safePage,
        pageSize,
        totalItems,
        totalPages,
        hasPrevPage: safePage > 1,
        hasNextPage: safePage < totalPages,
      },
      rounds: paginatedRounds,
    });
  }

  return NextResponse.json({ error: 'Unknown admin action' }, { status: 400 });
}
