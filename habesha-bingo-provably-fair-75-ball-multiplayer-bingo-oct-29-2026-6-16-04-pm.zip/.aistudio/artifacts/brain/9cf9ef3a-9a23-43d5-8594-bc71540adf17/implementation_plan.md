# Room Renaming & Admin Notice Space Optimization

## 1. Room Name Change & Enlarge
- **Renamed from "መርካቶ" to "ዋናው ጭዋታ" (Main Game)**:
  - Database schema seed in `src/db/users.ts` updated with `nameAm: 'ዋናው ጭዋታ'`, `nameEn: 'Main Game'`.
  - Added `getDisplayRoomName` helper across `app/page.tsx` mapping legacy room names to `ዋናው ጭዋታ`.
  - Enlarged the room title font in the lobby from `text-2xl sm:text-3xl` to `text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight drop-shadow-md` with an official sub-badge (`⭐ ዋናው የቀጥታ ቢንጎ ውድድር`).
  - Updated room switcher buttons in the game tab to show `ዋናው ጭዋታ` in prominent bold lettering.
  - Updated Admin panel room selectors and rooms management tab in `app/admin/page.tsx`.

## 2. Admin Notice & Countdown Size Optimization ("ቦታ እንዲበቃ")
- **Lobby Official Schedule Banner**:
  - Reduced outer padding from `p-5 sm:p-7 rounded-3xl border-4 ring-4` to a sleek `px-3.5 py-2.5 sm:px-4 sm:py-3 rounded-2xl border-2 ring-1`.
  - Scaled down the countdown box to `px-3.5 py-2 min-w-[140px]` with clear `text-xl sm:text-2xl font-black` digits.
  - Scaled down calendar icon from `w-14 h-14` to `w-9 h-9 sm:w-10 sm:h-10`.
- **Closed Game Mode Notices**:
  - Reduced Real Game Mode OFF and Practice Mode OFF notice banners to compact space-saving dimensions (`px-4 py-3 rounded-2xl border-2`, `w-9 h-9` icon, `text-sm sm:text-base font-bold`).
- **Game Screen Header Admin Schedule Pill**:
  - Streamlined to compact `px-2.5 py-1.5 rounded-xl border` so cards and gameplay have maximum screen visibility.

## 3. Verification
- `compile_applet`: Succeeded with zero errors.
- `lint_applet`: Passed with 0 errors.
- Dev server responding with HTTP 200.
